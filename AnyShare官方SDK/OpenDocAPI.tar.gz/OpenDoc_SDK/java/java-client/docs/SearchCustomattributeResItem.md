# SearchCustomattributeResItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | 属性名称 | 
**id** | **Long** | 属性唯一ID | 
**type** | **Long** | 属性类型  0：层级  1：枚举  2：数字  3：文本  4：时间 （时间戳）   | 
