# MessageGetResMsgType19

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applycsflevel** | **Long** | 所申请的密级 | 
