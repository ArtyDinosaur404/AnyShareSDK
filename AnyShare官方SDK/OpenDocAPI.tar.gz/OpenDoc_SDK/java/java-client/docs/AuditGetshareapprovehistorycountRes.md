# AuditGetshareapprovehistorycountRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Long** | 共享审核历史总数 | 
