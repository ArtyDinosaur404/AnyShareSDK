# GroupdocAddRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 群组对应入口文档的id | 
**typename** | **String** | 群组文档的类别显示名称 | 
