# FavoritesCheckResItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件或文件夹gns路径（目录列举协议返回） | 
**favorited** | **Boolean** | 文件或文件夹是否被收藏 | 
