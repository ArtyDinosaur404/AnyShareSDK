# DeviceGetstatusRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eraseflag** | **Long** | 数据擦除状态  0表示正常  1表示正在请求擦除 | 
**disableflag** | **Long** | 设备禁用状态  0表示正常  1表示处于禁用状态 | 
