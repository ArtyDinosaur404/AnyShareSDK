# MessageGetResMsgType2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowvalue** | **Long** | 允许的权限值，按bit为存储，参考权限获取 | 
**denyvalue** | **Long** | 拒绝的权限值，按bit为存储，参考权限获取 | 
**end** | **Long** | 有效到期时间 (unix utc 精确到微秒)  -1 无限期 | 
