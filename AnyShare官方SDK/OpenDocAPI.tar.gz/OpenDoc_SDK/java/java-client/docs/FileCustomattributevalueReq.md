# FileCustomattributevalueReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attributeid** | **Long** | 属性ID | 
