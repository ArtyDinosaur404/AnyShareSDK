# AuditGetshareapprovehistoryResApplyinfoType5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetshareapplyhistoryResApplyinfoType5Detail**](AuditGetshareapplyhistoryResApplyinfoType5Detail.md) |  |  [optional]
