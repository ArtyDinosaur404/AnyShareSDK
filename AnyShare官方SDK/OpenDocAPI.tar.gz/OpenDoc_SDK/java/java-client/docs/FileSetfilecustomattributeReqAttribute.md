# FileSetfilecustomattributeReqAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | 属性ID | 
**value** | [**Object**](.md) | 属性值string/int/int array    type等于3时value类型为string，0为int array, 其余均为int    注： 时长单位为秒   |  [optional]
