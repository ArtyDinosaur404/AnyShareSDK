# ConfigGetReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ostype** | **Long** | 设备类型 |  [optional]
