# DirCreatemultileveldirReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 待创建多级目录的父目录gns路径 | 
**path** | **String** | 多级目录名称，UTF8编码 | 
