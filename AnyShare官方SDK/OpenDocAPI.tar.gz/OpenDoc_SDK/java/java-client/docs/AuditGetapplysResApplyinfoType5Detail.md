# AuditGetapplysResApplyinfoType5Detail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applycsflevel** | **Long** | 所要申请的密级大小 | 
**doccsflevel** | **Long** | 文档密级，文件夹为子对象中的最大密级 | 
**usercsflevel** | **Long** | 申请时用户密级 | 
