# PkiOriginalRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** | 服务器返回的original值 | 
