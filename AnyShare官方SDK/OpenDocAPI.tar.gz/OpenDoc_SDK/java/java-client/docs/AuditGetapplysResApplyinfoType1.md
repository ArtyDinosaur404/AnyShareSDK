# AuditGetapplysResApplyinfoType1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetapplysResApplyinfoType1Detail**](AuditGetapplysResApplyinfoType1Detail.md) |  |  [optional]
