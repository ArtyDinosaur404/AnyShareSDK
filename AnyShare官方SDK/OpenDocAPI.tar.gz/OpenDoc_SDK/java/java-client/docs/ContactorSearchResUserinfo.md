# ContactorSearchResUserinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userid** | **String** | 用户唯一标识 | 
**account** | **String** | 用户登录账号 | 
**name** | **String** | 用户显示名 | 
**mail** | **String** | 用户邮箱地址 | 
**csflevel** | **Long** | 用户密级，5~15 | 
**groupid** | **String** | 用户直属联系人组id | 
**groupname** | **String** | 用户直属联系人组名称 | 
