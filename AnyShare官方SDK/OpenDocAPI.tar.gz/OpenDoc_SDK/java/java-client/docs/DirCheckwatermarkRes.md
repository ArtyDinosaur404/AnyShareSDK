# DirCheckwatermarkRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**watermarktype_** | **Long** | 水印类型(0:无水印，1：预览水印，2:下载水印，3：预览下载水印) | 
**watermarkconfig** | **String** | 水印配置信息 | 
