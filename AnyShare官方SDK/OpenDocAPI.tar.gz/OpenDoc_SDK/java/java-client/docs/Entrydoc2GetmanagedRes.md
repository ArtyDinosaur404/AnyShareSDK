# Entrydoc2GetmanagedRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docinfos** | [**List&lt;Entrydoc2GetmanagedResDocinfo&gt;**](Entrydoc2GetmanagedResDocinfo.md) | 文档库信息数组 | 
