# Auth1GetvcodeRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uuid** | **String** | 验证码唯一标识 | 
**vcode** | **String** | 编码后的验证码字符串 | 
