# Auth1GetnewReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **String** | 用户登录账号 | 
**password** | **String** | 加密后的密文 | 
**deviceinfo** | [**Auth1GetnewReqDeviceinfo**](Auth1GetnewReqDeviceinfo.md) |  |  [optional]
**vcodeinfo** | [**Auth1GetnewReqVcodeinfo**](Auth1GetnewReqVcodeinfo.md) |  |  [optional]
**dualfactorauthinfo** | **Map&lt;String, Object&gt;** | 双因子登录的验证信息 |  [optional]
