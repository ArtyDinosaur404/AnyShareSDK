# Auth1GetextappinfoReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**apptype** | **Long** | 外部应用标识 | 
**params** | **Map&lt;String, Object&gt;** | 应用系统相关配置 | 
