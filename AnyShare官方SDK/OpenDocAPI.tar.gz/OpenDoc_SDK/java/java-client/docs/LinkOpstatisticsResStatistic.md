# LinkOpstatisticsResStatistic

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip** | **String** | 访问ip | 
**download** | **Long** | 下载量 | 
**preview** | **Long** | 预览量 | 
