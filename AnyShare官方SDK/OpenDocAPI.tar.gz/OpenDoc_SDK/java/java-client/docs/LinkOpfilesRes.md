# LinkOpfilesRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**List&lt;LinkOpfilesResFile&gt;**](LinkOpfilesResFile.md) | 文件信息数组 | 
