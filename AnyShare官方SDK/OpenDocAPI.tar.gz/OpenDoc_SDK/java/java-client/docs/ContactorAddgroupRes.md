# ContactorAddgroupRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupid** | **String** | 联系人组唯一标识 | 
