# FavoritesDeleteReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件或文件夹gns路径（收藏或目录list协议返回） | 
