# AuditGetpendingapprovalsResApplyinfoType6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetapplysResApplyinfoType6Detail**](AuditGetapplysResApplyinfoType6Detail.md) |  |  [optional]
