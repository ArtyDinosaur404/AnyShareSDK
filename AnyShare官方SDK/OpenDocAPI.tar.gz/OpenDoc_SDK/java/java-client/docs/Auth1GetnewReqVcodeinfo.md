# Auth1GetnewReqVcodeinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uuid** | **String** | 验证码唯一标识 |  [optional]
**vcode** | **String** | 验证码字符串 |  [optional]
**ismodify** | **Boolean** | 修改密码界面标识符 |  [optional]
