# FileRestorerevisionReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 需要还原版本的文件gns路径 | 
**rev** | **String** | 版本号 | 
