# FileGetappmetadataResItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appid** | **String** | 应用 id | 
**appname** | **String** | 应用名 | 
**appmetadata** | **Map&lt;String, String&gt;** | json 格式的应用元数据集合，key-value string 的形式 | 
