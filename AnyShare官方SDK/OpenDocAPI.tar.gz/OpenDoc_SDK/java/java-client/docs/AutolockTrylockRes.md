# AutolockTrylockRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issucceed** | **Boolean** | 锁定文件成功则返回true，文件已被其他用户锁定则返回false | 
**lockerid** | **String** | 文件已被其他用户时，锁定者的用户id |  [optional]
**lockeraccount** | **String** | 文件已被其他用户时，锁定者用户名 |  [optional]
**lockername** | **String** | 文件已被其他用户时，锁定者显示名 |  [optional]
