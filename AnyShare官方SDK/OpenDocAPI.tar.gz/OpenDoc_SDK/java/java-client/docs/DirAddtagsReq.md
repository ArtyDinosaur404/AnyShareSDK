# DirAddtagsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 目录gns路径（列举协议返回） | 
**tags** | **List&lt;String&gt;** | 标签数组，添加的标签中，不允许包含 \\/:*?\\\&quot;&lt;&gt;|# | 
