# AuditGetapplysResApplyinfoType2Detail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessLimit** | **Long** | 最大访问次数，-1表示不限制 | 
**endtime** | **Long** | 截止时间 | 
**link** | **String** | 外链唯一标识 | 
**optype** | **Long** | 外链操作类型  1表示新增  2表示编辑 | 
**password** | **String** | 访问密码 | 
**perm** | **Long** | 外链权限 | 
**watermarkConfig** | **String** | 水印配置信息 | 
