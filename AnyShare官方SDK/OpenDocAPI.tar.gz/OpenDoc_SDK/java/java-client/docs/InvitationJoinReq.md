# InvitationJoinReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**invitationid** | **String** | 邀请链接唯一标识 | 
