# AuditPublishdocReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processid** | **String** | 流程id | 
**docid** | **String** | 文档gns路径 | 
**applymsg** | **String** | 发起流程时的理由 | 
**recipients** | [**List&lt;AuditPublishdocReqRecipient&gt;**](AuditPublishdocReqRecipient.md) | 内外网数据交换目的位置 |  [optional]
**dstdocname** | **String** | 内外网数据交换文档接收位置 |  [optional]
