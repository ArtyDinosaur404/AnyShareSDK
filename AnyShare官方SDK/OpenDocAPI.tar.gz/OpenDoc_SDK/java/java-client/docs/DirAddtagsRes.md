# DirAddtagsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagMaxNum** | **Long** | 允许目录拥有的标签的最大数量 | 
**unsettagnum** | **Long** | 由于标签数量限制未设置成功的标签数 | 
**unsettags** | **List&lt;String&gt;** | 未设置成功的标签数组 | 
