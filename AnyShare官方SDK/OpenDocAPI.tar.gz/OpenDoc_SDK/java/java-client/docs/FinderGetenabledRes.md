# FinderGetenabledRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docinfos** | [**List&lt;FinderGetenabledResDocinfo&gt;**](FinderGetenabledResDocinfo.md) | 获取到的文档信息 | 
