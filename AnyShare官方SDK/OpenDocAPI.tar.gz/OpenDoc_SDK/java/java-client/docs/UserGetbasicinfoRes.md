# UserGetbasicinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**directdepinfos** | [**List&lt;UserGetbasicinfoResDeppath&gt;**](UserGetbasicinfoResDeppath.md) | 直属部门信息 | 
