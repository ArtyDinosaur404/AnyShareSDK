# AutolockGetlockedfileinfosRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docinfos** | [**List&lt;AutolockGetlockedfileinfosResDocinfo&gt;**](AutolockGetlockedfileinfosResDocinfo.md) | 当前用户所有文件锁信息，包含自己锁定和自己有所有者权限但被他人锁定的。 | 
