# ContactorGetpersonsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupid** | **String** | 联系人组唯一标识 | 
**start** | **Long** | 分页开始号，从0开始 | 
**limit** | **Long** | 条数，表示取多少联系人，-1表示不限制 | 
