# FavoritesAddReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件或文件夹gns路径（目录列举协议返回） | 
