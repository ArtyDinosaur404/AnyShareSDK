# SearchTagsuggestRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggestions** | **List&lt;String&gt;** | 建议的标签字符串数组 | 
