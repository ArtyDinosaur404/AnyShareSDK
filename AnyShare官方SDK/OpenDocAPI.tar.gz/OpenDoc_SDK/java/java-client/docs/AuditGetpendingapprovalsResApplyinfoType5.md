# AuditGetpendingapprovalsResApplyinfoType5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetapplysResApplyinfoType5Detail**](AuditGetapplysResApplyinfoType5Detail.md) |  |  [optional]
