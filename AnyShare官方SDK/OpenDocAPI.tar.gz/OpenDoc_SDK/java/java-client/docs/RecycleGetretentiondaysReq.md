# RecycleGetretentiondaysReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 个人文档或者文档库的gns路径 | 
