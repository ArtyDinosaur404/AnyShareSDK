# DirSetcsflevelReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**csflevel** | **Long** | 文件密级：5~15 | 
**docid** | **String** | 目录gns路径（列举协议返回） | 
