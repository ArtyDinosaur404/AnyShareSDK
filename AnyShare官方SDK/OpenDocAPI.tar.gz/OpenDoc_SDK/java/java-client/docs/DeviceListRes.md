# DeviceListRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deviceinfos** | [**List&lt;DeviceListResDeviceinfo&gt;**](DeviceListResDeviceinfo.md) | 设备信息数组 | 
