# Auth1GetconfigResExtapp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enableChaojibiaoge** | **Boolean** | 是否启用外部应用超级表格，默认为false | 
