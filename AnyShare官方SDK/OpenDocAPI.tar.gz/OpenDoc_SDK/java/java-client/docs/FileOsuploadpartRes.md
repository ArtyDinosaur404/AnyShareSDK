# FileOsuploadpartRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authrequests** | [**Map&lt;String, List&lt;String&gt;&gt;**](List.md) | 分块上传信息map，键为数据块号，值为上传信息authrequest - authrequest[0]：请求方法 - authrequest[1]: 待上传的资源URL - authrequest[2]及以后项：请求头，格式为“key: value” | 
