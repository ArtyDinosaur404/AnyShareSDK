# MessageGetResMsgType17

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auditmsg** | **String** | 审核意见 | 
**auditorname** | **String** | 审核员名字 | 
**auditresult** | **Boolean** | 审核结果 true表示通过 false表示拒绝 | 
**docaudittype** | **Long** | 审核模式 | 
**processname** | **String** | 文档流程名称 | 
