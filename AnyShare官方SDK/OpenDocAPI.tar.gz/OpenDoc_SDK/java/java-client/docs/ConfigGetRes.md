# ConfigGetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cache** | [**List&lt;ConfigGetResCache&gt;**](ConfigGetResCache.md) | 缓存相关配置信息 | 
**detectInterval** | **Long** | 客户端探测时间 | 
**localsync** | [**ConfigGetResLocalsync**](ConfigGetResLocalsync.md) |  | 
**needquickstart** | **Boolean** | 快速入门文档阅读状态 | 
