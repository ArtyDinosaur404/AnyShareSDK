# AuditGetapplysResApplyinfoType3Detail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessorid** | **String** | 访问者id | 
**accessorname** | **String** | 访问者名称 | 
**accessortype** | **Long** | 访问者类型 | 
**endtime** | **Long** | 截止时间 | 
**optype** | **Long** | 操作类型  1表示新增  3表示删除 | 
