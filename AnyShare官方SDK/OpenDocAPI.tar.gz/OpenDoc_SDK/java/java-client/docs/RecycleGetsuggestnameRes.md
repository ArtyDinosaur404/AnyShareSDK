# RecycleGetsuggestnameRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | 获取回收站还原后的建议名称 | 
