# AuditApprovedocReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applyid** | **String** | 申请记录id | 
**result** | **Boolean** | true表示通过 false表示拒绝 null表示拒绝 | 
**auditmsg** | **String** | 审核说明 | 
