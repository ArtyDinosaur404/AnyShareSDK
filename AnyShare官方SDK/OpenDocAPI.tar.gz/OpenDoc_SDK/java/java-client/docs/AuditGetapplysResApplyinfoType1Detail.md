# AuditGetapplysResApplyinfoType1Detail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessorid** | **String** | 访问者id | 
**accessorname** | **String** | 访问者名称 | 
**accessortype** | **Long** | 访问者类型 | 
**allowvalue** | **Long** | 允许权限值 | 
**denyvalue** | **Long** | 拒绝的权限值 | 
**endtime** | **Long** | 截止时间 | 
**optype** | **Long** | 权限操作类型  1表示新增  2表示编辑  3表示删除 | 
