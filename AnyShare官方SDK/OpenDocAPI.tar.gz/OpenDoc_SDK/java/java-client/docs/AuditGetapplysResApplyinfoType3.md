# AuditGetapplysResApplyinfoType3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetapplysResApplyinfoType3Detail**](AuditGetapplysResApplyinfoType3Detail.md) |  |  [optional]
