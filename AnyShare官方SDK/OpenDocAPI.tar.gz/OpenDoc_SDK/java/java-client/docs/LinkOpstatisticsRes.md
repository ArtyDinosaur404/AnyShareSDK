# LinkOpstatisticsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statistics** | [**List&lt;LinkOpstatisticsResStatistic&gt;**](LinkOpstatisticsResStatistic.md) | 统计信息数组 | 
