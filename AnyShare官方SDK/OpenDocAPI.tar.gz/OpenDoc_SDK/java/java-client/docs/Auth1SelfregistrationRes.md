# Auth1SelfregistrationRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userid** | **String** | 用户唯一标识 | 
