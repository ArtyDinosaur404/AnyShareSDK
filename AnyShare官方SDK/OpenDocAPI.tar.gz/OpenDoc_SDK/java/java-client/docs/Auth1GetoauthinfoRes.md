# Auth1GetoauthinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isenabled** | **Boolean** | 是否开启 | 
**authurl** | **String** | 完整的OAuth认证地址 | 
**authserver** | **String** | 认证服务器地址 | 
**redirectserver** | **String** | 第三方认证完毕后，跳转到AnyShare服务器的地址 | 
