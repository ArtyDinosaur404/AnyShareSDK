# FinderGetstatusRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **Boolean** | 1表示开启，0表示没开启 | 
