# RecycleRestoreReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 要还原的文件/目录在回收站的gns路径（可以是回收站的子目录或者子文件） | 
**ondup** | **Long** | 1:检查是否重命名，重名则抛异常  2:如果重名冲突，自动重名   | 
