# FileSendReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 要发送的文件gns路径 | 
**recipients** | **List&lt;String&gt;** | 收件人名字，为用户登录名，UTF8编码 | 
