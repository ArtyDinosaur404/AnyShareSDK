# FileGetinfobypathReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**namepath** | **String** | 名字路径，由顶级入口（个人文档/文档库/群组等）开始的对象全路径，以”/”分隔 | 
