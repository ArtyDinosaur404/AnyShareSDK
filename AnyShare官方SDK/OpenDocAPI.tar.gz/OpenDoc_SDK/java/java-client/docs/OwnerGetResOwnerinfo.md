# OwnerGetResOwnerinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userid** | **String** | 用户ID | 
**account** | **String** | 用户登录账号 | 
**name** | **String** | 用户的显示名称 | 
**inheritpath** | **String** | 所有者的继承路径 | 
**csflevel** | **Long** | 用户密级 | 
