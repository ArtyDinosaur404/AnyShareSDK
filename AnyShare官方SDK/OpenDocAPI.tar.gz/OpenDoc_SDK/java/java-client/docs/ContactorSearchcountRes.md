# ContactorSearchcountRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Long** | 搜索数目 | 
