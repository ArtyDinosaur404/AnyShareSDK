# AuditGetdocprocessesRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processinfos** | [**List&lt;AuditGetdocprocessesResProcessinfo&gt;**](AuditGetdocprocessesResProcessinfo.md) | 流程信息 | 
