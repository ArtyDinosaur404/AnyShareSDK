# ContactorGetpersonsResUserinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**departname** | **List&lt;String&gt;** | 联系人所属部门名称 | 
**email** | **String** | 用户邮箱地址 | 
**userid** | **String** | 用户唯一标识 | 
**username** | **String** | 用户显示名 | 
