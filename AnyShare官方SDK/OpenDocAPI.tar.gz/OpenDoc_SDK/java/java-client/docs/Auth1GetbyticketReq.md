# Auth1GetbyticketReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ticket** | **String** | auth服务器返回的ticket票据，用来向token服务器请求token | 
**service** | **String** | 请求ticket时的service名称 | 
