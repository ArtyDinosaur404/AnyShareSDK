# LinkGetReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **String** | 外链唯一标识，如FC5E038D38A57032085441E7FE7010B0 | 
**password** | **String** | 密码 | 
**docid** | **String** | 文件gns路径，通过文件夹外链访问文件信息时，需要该参数，默认为空 |  [optional]
