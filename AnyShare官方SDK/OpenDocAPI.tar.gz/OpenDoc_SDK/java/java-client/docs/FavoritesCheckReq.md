# FavoritesCheckReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docids** | **List&lt;String&gt;** | 文件或文件夹gns数组 | 
