# ConfigGetResCache

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interval** | **Long** | 缓存清除时间间隔 | 
**size** | **Long** | 缓存清除空间上限 | 
