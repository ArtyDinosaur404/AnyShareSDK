# Entrydoc2GetuserquotaResQuotainfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doctype** | **Long** | 文档库类型：  1：个人文档库  2：个人群组文档库   | 
**typename** | **String** | 文档库类型名称 | 
**docid** | **String** | 文档库id | 
**name** | **String** | 文档库名称 | 
**quota** | **Long** | 配额 | 
**used** | **Long** | 已用空间 | 
