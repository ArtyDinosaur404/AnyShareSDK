# Auth1GetconfigResWindowsadsso

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isEnabled** | **Boolean** | 是否开启了windows ad单点登录 | 
