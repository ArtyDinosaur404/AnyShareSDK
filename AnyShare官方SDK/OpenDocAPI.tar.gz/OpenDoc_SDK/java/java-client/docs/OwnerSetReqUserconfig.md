# OwnerSetReqUserconfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userid** | **String** | 用户ID | 
**inheritpath** | **String** | 所有者的继承路径，被设置为当前文档为空 | 
