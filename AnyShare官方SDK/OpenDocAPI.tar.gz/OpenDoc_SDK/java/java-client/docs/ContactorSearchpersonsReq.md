# ContactorSearchpersonsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | 关键字 | 
