# ContactorSearchpersonsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userinfos** | [**List&lt;ContactorSearchpersonsResUserinfo&gt;**](ContactorSearchpersonsResUserinfo.md) | 联系人信息 | 
