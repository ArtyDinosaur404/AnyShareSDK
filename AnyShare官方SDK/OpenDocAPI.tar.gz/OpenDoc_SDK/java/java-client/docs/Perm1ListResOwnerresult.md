# Perm1ListResOwnerresult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessorid** | **String** | 访问者id | 
**accessortype** | [**AccessortypeEnum**](#AccessortypeEnum) | 访问者类型 | 
**accessorname** | **String** | 访问者的名称 | 

<a name="AccessortypeEnum"></a>
## Enum: AccessortypeEnum
Name | Value
---- | -----
USER | &quot;user&quot;
DEPARTMENT | &quot;department&quot;
CONTACTOR | &quot;contactor&quot;
