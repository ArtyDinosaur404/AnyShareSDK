# AutolockGetdirlockinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**islocked** | **Boolean** | 文件夹下有锁定文件则返回true，  文件下没有锁定文件则返回false | 
