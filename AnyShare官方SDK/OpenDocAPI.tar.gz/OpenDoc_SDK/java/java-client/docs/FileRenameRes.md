# FileRenameRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | UTF8编码，仅当ondup为2时才返回，否则返回参数仍然为空 |  [optional]
