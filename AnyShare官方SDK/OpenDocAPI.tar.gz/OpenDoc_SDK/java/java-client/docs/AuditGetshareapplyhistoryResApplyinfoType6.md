# AuditGetshareapplyhistoryResApplyinfoType6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetshareapplyhistoryResApplyinfoType6Detail**](AuditGetshareapplyhistoryResApplyinfoType6Detail.md) |  |  [optional]
