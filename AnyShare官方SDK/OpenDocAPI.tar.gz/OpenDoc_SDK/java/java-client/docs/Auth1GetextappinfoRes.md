# Auth1GetextappinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Map&lt;String, Object&gt;** | 返回登录信息 | 
