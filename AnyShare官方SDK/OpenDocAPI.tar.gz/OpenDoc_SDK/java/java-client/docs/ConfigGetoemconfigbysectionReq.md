# ConfigGetoemconfigbysectionReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**section** | [**SectionEnum**](#SectionEnum) | 语言标签 | 

<a name="SectionEnum"></a>
## Enum: SectionEnum
Name | Value
---- | -----
SHAREWEB_EN_US | &quot;shareweb_en-us&quot;
SHAREWEB_ZH_CN | &quot;shareweb_zh-cn&quot;
SHAREWEB_ZH_TW | &quot;shareweb_zh-tw&quot;
ANYSHARE | &quot;anyshare&quot;
