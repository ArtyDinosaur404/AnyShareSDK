# RedirectGethostinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **String** | 系统对外的域名或ip | 
**name** | **String** | 系统对外的站点名称 | 
**port** | **Long** | http端口：  1. 0918版本之前的客户端使用该端口进行下载客户端  2. 10xx后续的服务器使用该端口来访问视频播放服务 | 
**httpsPort** | **Long** | Web client的服务端口，采用https | 
