# RecycleRestoreRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 还原后文件/目录的gns路径，如果父目录为新创建的，返回docid可能与传入的不同 | 
**name** | **String** | 当ondup为2（自动重名）时才返回 |  [optional]
