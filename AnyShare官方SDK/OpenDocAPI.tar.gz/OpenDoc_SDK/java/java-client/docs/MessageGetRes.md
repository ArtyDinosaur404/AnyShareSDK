# MessageGetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stamp** | **Long** | 最后接收的通知的时间 (unix utc ns)，可供下次get时使用 | 
**msgs** | **List&lt;Object&gt;** | 消息结构体 |  [optional]
