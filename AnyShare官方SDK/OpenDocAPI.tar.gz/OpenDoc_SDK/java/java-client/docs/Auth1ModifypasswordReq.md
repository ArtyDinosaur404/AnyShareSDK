# Auth1ModifypasswordReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **String** | 用户登录名 | 
**oldpwd** | **String** | 用户旧密码 | 
**newpwd** | **String** | 用户新密码 | 
