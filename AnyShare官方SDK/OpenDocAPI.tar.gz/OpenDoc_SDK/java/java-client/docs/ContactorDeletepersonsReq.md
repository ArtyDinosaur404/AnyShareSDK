# ContactorDeletepersonsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupid** | **String** | 联系人组唯一标识 | 
**userids** | **List&lt;String&gt;** | 待添加的联系人id | 
