# LinkOsenduploadReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**crc32** | **String** | 文件的CRC32校验码 |  [optional]
**docid** | **String** | 文件gns路径（创建协议返回） | 
**md5** | **String** | 文件MD5值 |  [optional]
**sliceMd5** | **String** | 文件的slice_md5 |  [optional]
**rev** | **String** | 文件版本号 | 
**link** | **String** | 外链ID | 
