# MessageGetResMsgType14

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**perm** | **Long** | 外链权限，参考外链 | 
**end** | **Long** | 有效到期时间 (unix utc 精确到微秒)  -1 无限期 | 
**auditorname** | **String** | 审核员名字 | 
**auditresult** | **Boolean** | 审核结果 true表示通过 false表示拒绝 | 
**auditmsg** | **String** | 审核意见 | 
