# QuarantineListreversionRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modified** | **Long** | 版本修改时间 | 
**modifier** | **String** | 版本修改者名称 | 
**name** | **String** | 版本名称 | 
**reason** | **String** | 版本隔离原因 | 
**rev** | **String** | 版本id | 
