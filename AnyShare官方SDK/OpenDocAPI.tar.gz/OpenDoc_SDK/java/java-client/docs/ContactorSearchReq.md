# ContactorSearchReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | 关键字 | 
**start** | **Long** | 分页开始号，从0开始 |  [optional]
**limit** | **Long** | 条数，表示取多少联系人，-1表示不限制 |  [optional]
