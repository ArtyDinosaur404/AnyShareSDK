# Linkcheckwatermarkreq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档docid | 
**link** | **String** | 外链id |  [optional]
