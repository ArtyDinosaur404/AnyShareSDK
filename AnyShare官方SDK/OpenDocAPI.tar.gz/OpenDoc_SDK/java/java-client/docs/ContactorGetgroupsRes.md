# ContactorGetgroupsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groups** | [**List&lt;ContactorGetgroupsResGroup&gt;**](ContactorGetgroupsResGroup.md) | 联系人分组信息 | 
