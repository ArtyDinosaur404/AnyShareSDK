# Perm1GetinternallinktemplateRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowperm** | **Long** | 允许设置的权限 | 
**defaultperm** | **Long** | 默认设置的权限 | 
**allowowner** | **Boolean** | 允许设定所有者 | 
**defaultowner** | **Boolean** | 默认允许设置所有者 | 
**limitexpiredays** | **Boolean** | 是否限制有效期 | 
**allowexpiredays** | **Long** | limitexpiredays&#x3D;true  表示最大有效期  limitexpiredays&#x3D;false  表示默认有效期 | 
