# AuditGetapplyhistoryReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **Long** | 分页开始号，从0开始 | 
**limit** | **Long** | 条数，表示取多少条记录，-1表示不限制 | 
