# QuarantinePreviewReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件docid | 
**rev** | **String** | 预览版本ID （不可为空） | 
**reqhost** | **String** | 从存储服务器下载数据时的请求地址从存储服务器下载数据时的请求地址 |  [optional]
**usehttps** | **Boolean** | 是否使用https下载数据，默认为true |  [optional]
