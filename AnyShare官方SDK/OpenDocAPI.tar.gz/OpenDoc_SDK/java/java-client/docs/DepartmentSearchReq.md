# DepartmentSearchReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | 关键字 | 
**start** | **Long** | 分页开始号，从0开始 |  [optional]
**limit** | **Long** | 条数，表示取多少用户或部门，-1表示不限制 |  [optional]
