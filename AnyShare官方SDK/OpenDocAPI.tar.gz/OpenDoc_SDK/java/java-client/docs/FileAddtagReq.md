# FileAddtagReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件gns路径（列举协议返回） | 
**tag** | **String** | 标签名 | 
