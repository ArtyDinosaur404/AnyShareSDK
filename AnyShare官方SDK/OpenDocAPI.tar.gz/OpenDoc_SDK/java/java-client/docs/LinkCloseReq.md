# LinkCloseReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 待关闭外链的对象gns路径 | 
