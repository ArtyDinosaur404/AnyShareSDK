# GroupdocEditReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 群组对应的文档id | 
**name** | **String** | 群组的新名称 | 
