# AuditGetapprovehistoryRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applyinfos** | [**List&lt;AuditGetapprovehistoryResApplyinfo&gt;**](AuditGetapprovehistoryResApplyinfo.md) | 申请信息 | 
