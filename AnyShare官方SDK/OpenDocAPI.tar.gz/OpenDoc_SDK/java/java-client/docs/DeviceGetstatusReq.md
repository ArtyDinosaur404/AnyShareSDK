# DeviceGetstatusReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**udid** | **String** | 设备唯一标识 | 
