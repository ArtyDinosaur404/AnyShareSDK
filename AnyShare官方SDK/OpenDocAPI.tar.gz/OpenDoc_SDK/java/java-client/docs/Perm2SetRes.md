# Perm2SetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Long** | 执行结果  0表示没有权限变化或成功  1表示已提交审核   | 
