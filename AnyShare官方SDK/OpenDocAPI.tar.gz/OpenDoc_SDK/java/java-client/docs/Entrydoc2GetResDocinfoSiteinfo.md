# Entrydoc2GetResDocinfoSiteinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | 站点id，下列情况为空字符串：  个人文档库  个人群组文档库  共享个人文档库  共享个人群组文档库  站点未归属 | 
**name** | **String** | 站点名称，下列情况为空字符串：  个人文档库  个人群组文档库  共享个人文档库  共享个人群组文档库  站点未归属 | 
