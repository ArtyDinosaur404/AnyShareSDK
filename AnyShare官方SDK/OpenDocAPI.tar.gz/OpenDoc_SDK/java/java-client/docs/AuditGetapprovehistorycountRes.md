# AuditGetapprovehistorycountRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Long** | 流程审核历史总数 | 
