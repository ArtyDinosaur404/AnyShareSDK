# Auth1SelfregistrationReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**registerid** | **String** | 注册号 | 
**certid** | **String** | 身份证号 | 
**realname** | **String** | 真实姓名 | 
**password** | **String** | 用户密码（采用RSA加密并将加密结果使用base64编码） | 
