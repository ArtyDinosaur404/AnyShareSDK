# CaGetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enable** | **Boolean** | 是否开启了CA认证 true表示开启 false表示关闭 | 
**cainfo** | [**CaGetResCainfo**](CaGetResCainfo.md) |  |  [optional]
