# LinkOpstatisticsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**linkDocid** | **String** | 外链文件gns路径（getlinked协议返回） | 
**fileDocid** | **String** | 文件gns（opfiles协议返回） | 
**start** | **Long** | 开始位置，默认为0 |  [optional]
**limit** | **Long** | 分页条数，默认为-1，返回start后面的所有记录 |  [optional]
