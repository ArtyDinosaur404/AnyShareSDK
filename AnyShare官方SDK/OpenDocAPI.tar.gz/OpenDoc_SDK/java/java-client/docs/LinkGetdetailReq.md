# LinkGetdetailReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 待获取外链信息的对象gns路径 | 
