# FileSendRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**List&lt;FileSendResResult&gt;**](FileSendResResult.md) | 表示多条发送文件的返回信息 | 
