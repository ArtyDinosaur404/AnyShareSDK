# ConfigGetResLocalsync

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**openstatus** | **Boolean** | 是否开启本地同步配置 | 
**deletestatus** | **Boolean** | 是否允许删除配置的同步任务 | 
