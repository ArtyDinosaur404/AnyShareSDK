# LinkOpfilesResFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件gns | 
**name** | **String** | 文件名 | 
**path** | **String** | 文件路径，以外链文件或文件夹为根 | 
