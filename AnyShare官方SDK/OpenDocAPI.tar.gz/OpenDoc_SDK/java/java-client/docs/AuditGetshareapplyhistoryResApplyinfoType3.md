# AuditGetshareapplyhistoryResApplyinfoType3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetshareapplyhistoryResApplyinfoType3Detail**](AuditGetshareapplyhistoryResApplyinfoType3Detail.md) |  |  [optional]
