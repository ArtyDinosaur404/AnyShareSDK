# FileCustomattributevalueResItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | 属性值ID | 
**name** | **String** | 属性值名称 | 
**level** | **Long** | 属性值层级 | 
**child** | [**List&lt;FileCustomattributevalueResItem&gt;**](FileCustomattributevalueResItem.md) | 属性值子属性：包括以上三个字段的数组 |  [optional]
