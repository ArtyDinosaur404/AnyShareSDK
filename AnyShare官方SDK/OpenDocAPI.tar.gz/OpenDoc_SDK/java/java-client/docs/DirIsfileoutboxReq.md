# DirIsfileoutboxReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 目录gns路径（列举协议返回） | 
