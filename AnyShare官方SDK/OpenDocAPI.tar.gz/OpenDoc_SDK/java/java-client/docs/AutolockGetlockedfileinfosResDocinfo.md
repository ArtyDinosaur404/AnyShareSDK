# AutolockGetlockedfileinfosResDocinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locktime** | **Long** | 文件锁创建时间（微秒时间戳） | 
**docid** | **String** | 文件id | 
**lockeraccount** | **String** | 锁定者用户名 | 
**lockerid** | **String** | 锁定者id | 
**lockername** | **String** | 锁定者显示名 | 
**path** | **String** | 文件路径 | 
