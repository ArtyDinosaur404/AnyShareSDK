# Auth1CheckuninstallpwdRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **String** | 接口调用成功 | 
