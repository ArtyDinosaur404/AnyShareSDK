# DirCopyprogressReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | 复制任务的id | 
