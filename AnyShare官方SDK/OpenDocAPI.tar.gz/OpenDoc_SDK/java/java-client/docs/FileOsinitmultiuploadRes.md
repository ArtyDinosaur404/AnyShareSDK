# FileOsinitmultiuploadRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件的gns路径 | 
**name** | **String** | 文件名称，UTF8编码，创建版本时返回 | 
**rev** | **String** | 文件版本号 | 
**uploadid** | **String** | 标识本次Multipart Upload事件 | 
