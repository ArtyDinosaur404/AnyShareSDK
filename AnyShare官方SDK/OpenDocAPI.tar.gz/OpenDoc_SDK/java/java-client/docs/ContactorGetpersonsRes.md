# ContactorGetpersonsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userinfos** | [**List&lt;ContactorGetpersonsResUserinfo&gt;**](ContactorGetpersonsResUserinfo.md) | 联系人信息 | 
