# Auth1GetconfigResDeviceinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authDays** | **Long** | 授权天数 | 
**authStatus** | **Long** | 授权状态 1未授权 2已授权 3已过期 4已失效 | 
**authType** | **Long** | 授权类型 1未授权 2测试授权 3正式授权 | 
**hardwareType** | **String** | 设备型号 | 
**softwareType** | **String** | 当前产品类型信息  EDMS: 涉密一体机  ASE：AnyShare Enterprise  ASS：AnyShare Express  ASC：AnyShare Cloud | 
