# DepartmentGetsubdepsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**depinfos** | [**List&lt;DepartmentGetsubdepsResDepinfo&gt;**](DepartmentGetsubdepsResDepinfo.md) | 部门信息 | 
