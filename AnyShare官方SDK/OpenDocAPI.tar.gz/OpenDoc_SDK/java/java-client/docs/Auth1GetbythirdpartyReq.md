# Auth1GetbythirdpartyReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thirdpartyid** | **String** | 标识第三方认证类型 | 
**params** | **Map&lt;String, Object&gt;** | 保存第三方认证系统相关的参数 | 
**deviceinfo** | [**Auth1GetbythirdpartyReqDeviceinfo**](Auth1GetbythirdpartyReqDeviceinfo.md) |  | 
