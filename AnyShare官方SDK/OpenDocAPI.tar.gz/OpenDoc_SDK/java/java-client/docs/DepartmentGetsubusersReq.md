# DepartmentGetsubusersReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**depid** | **String** | 部门id | 
