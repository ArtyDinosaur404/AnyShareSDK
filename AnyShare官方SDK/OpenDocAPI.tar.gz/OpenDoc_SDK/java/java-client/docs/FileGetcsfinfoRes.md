# FileGetcsfinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**csfinfo** | **Map&lt;String, String&gt;** | json 格式的应用元数据集合，key-value string 的形式 | 
