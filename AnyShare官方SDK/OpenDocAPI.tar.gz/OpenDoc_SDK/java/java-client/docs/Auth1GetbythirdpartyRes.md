# Auth1GetbythirdpartyRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userid** | **String** | 唯一标识用户的ID | 
**tokenid** | **String** | 与userid一起验证请求的合法性 | 
**expires** | **Long** | 获取到的token的有效期，单位为秒 | 
