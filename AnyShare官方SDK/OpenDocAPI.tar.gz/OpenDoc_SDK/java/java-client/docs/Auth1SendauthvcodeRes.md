# Auth1SendauthvcodeRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authway** | **String** | 用户手机号 | 
**sendinterval** | **Long** | 短信发送验证码的间隔（单位/秒） | 
**isduplicatesended** | **Boolean** | 是否重复发送了 true表示在时间间隔内重复发送了 false表示未重复发送 | 
