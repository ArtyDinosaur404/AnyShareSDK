# ConfigGetoemconfigbysectionRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**backgroundPng** | **String** | OEM图片资源 |  [optional]
**faviconIco** | **String** | OEM图片资源 |  [optional]
**logoPng** | **String** | OEM图片资源 |  [optional]
**orgPng** | **String** | OEM图片资源 |  [optional]
**helper** | **String** | 帮助文档链接地址 |  [optional]
**organization** | **String** | 组织机构 |  [optional]
**product** | **String** | 产品名称 |  [optional]
**site** | **String** | 官方链接 |  [optional]
**userAgreement** | **String** | 是否开启用户许可协议 |  [optional]
**agreementText** | **String** | 用户许可协议 |  [optional]
**android** | **String** | 开放android客户端下载 |  [optional]
**ios** | **String** | 开放iOS客户端下载 |  [optional]
**office** | **String** | 开放office插件下载 |  [optional]
**mac** | **String** | 开放mac客户端下载 |  [optional]
**windows** | **String** | 开放windows客户端下载 |  [optional]
**allowCn** | **String** | 允许简体中文 |  [optional]
**allowTw** | **String** | 允许繁体中文 |  [optional]
**allowEn** | **String** | 允许英文语言 |  [optional]
**theme** | **String** | 基本颜色值 |  [optional]
**showProduct** | **String** | 显示产品信息 |  [optional]
**showHardware** | **String** | 显示型号信息 |  [optional]
**showLicense** | **String** | 显示授权信息 |  [optional]
**showCopyright** | **String** | 显示版权信息 |  [optional]
