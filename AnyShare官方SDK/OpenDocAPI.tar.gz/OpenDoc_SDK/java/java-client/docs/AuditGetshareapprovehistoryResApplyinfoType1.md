# AuditGetshareapprovehistoryResApplyinfoType1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetshareapplyhistoryResApplyinfoType1Detail**](AuditGetshareapplyhistoryResApplyinfoType1Detail.md) |  |  [optional]
