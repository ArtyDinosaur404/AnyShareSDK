# MessageGetResMsgType30

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inherit** | **Boolean** | 是否使用继承 true表示启用继承 false表示禁用继承 | 
