# DepartmentSearchRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userinfos** | [**List&lt;DepartmentSearchResUserInfo&gt;**](DepartmentSearchResUserInfo.md) | 用户信息 | 
**depinfos** | [**List&lt;DepartmentSearchResDepinfo&gt;**](DepartmentSearchResDepinfo.md) | 部门信息 | 
