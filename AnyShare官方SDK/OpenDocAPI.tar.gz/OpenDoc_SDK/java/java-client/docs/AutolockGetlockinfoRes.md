# AutolockGetlockinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lockerid** | **String** | 文件已被其他用户时，锁定者的用户id |  [optional]
**lockeraccount** | **String** | 文件已被其他用户时，锁定者用户名 |  [optional]
**lockername** | **String** | 文件已被其他用户时，锁定者显示名 |  [optional]
**islocked** | **Boolean** | 文件锁定则返回true，文件未锁定则返回false | 
