# ContactorAddgroupReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupname** | **String** | 新建联系人组名称 | 
