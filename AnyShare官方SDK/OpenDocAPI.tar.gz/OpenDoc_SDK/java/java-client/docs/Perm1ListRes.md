# Perm1ListRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permresults** | [**List&lt;Perm1ListResPermresult&gt;**](Perm1ListResPermresult.md) | 最终权限信息 | 
**ownerresults** | [**List&lt;Perm1ListResOwnerresult&gt;**](Perm1ListResOwnerresult.md) | 最终所有者信息 | 
