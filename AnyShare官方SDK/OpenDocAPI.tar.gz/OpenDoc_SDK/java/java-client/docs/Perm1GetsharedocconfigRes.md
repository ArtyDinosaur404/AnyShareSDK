# Perm1GetsharedocconfigRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enableUserDocInnerLinkShare** | **Boolean** | 开启个人文档内链共享 | 
**enableUserDocOutLinkShare** | **Boolean** | 开启个人文档外链共享 | 
**enableGroupDocOutLinkShare** | **Boolean** | 开启群组文档外链共享 | 
**enableGroupDocInnerLinkShare** | **Boolean** | 开启群组文档内链共享 | 
