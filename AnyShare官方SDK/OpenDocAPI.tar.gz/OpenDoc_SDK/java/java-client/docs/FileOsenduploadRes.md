# FileOsenduploadRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**editor** | **String** | 编辑者 | 
**modified** | **Long** | 上传时间，UTC时间，此为上传版本完成时的服务器时间 | 
