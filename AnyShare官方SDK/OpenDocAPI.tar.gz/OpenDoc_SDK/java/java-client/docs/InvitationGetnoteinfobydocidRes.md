# InvitationGetnoteinfobydocidRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** | 邀请链接页面文件/文件夹图标 | 
**description** | **String** | 描述 | 
