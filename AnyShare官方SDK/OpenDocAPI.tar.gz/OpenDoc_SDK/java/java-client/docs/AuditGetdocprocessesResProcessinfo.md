# AuditGetdocprocessesResProcessinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auditornames** | **List&lt;String&gt;** | 所有审核员名称列表 | 
**audittype** | **Long** | 审核模式  1：同级审核  2：汇签审核  3：逐级审核 | 
**destpath** | **String** | 发布目的路径 | 
**processid** | **String** | 流程id | 
**processname** | **String** | 流程名称 | 
