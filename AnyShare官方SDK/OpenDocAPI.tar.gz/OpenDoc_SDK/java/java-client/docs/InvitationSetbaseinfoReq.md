# InvitationSetbaseinfoReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**invitationendtime** | **Long** | 邀请链接到期时间，如果为-1，表示无限期 | 
**invitationid** | **String** | 邀请链接唯一标识 | 
**perm** | **Long** | 权限值 | 
**permendtime** | **Long** | 权限到期时间，如果为-1，表示无限期 | 
