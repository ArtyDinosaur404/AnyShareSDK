# LinkCheckpermRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Boolean** | True or false | 
