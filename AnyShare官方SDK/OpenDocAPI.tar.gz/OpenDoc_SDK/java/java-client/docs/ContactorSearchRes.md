# ContactorSearchRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userinfos** | [**List&lt;ContactorSearchResUserinfo&gt;**](ContactorSearchResUserinfo.md) | 用户信息 | 
**groups** | [**List&lt;ContactorSearchResGroup&gt;**](ContactorSearchResGroup.md) | 联系人组信息 | 
