# FileRevisionsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 要列举版本的gns路径 | 
