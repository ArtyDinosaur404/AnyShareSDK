# MessageGetResMsgType28

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duedate** | **Long** | 到期时间 | 
**remindcontent** | **String** | 消息内容 | 
