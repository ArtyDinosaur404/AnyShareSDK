# Auth1SendauthvcodeReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **String** | 用户登录账号 | 
**password** | **String** | 加密后的密文 | 
**oldtelnum** | **String** | 上一次的获取的手机号（处理管理员修改手机号的情况） | 
**deviceinfo** | [**Auth1SendauthvcodeReqDeviceinfo**](Auth1SendauthvcodeReqDeviceinfo.md) |  |  [optional]
