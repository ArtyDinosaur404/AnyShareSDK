# ContactorGetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userinfos** | [**List&lt;ContactorGetResUserinfo&gt;**](ContactorGetResUserinfo.md) | 用户信息 | 
