# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errcode** | **Long** | 错误码 | 
**errmsg** | **String** | 错误描述，与错误码对应 | 
**causemsg** | **String** | 错误原因，底层错误信息，仅用于研发排错，客户端不应使用此字段内容 | 
