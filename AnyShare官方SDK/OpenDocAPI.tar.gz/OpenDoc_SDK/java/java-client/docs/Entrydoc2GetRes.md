# Entrydoc2GetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docinfos** | [**List&lt;Entrydoc2GetResDocinfo&gt;**](Entrydoc2GetResDocinfo.md) | 文档库信息数组 | 
