# LinkPreviewossRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**size** | **Long** | 所预览文件的大小 | 
**url** | **String** | 下载转换后文件的url(15分钟过期) | 
