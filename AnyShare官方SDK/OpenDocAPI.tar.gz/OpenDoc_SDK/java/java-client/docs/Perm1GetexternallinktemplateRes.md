# Perm1GetexternallinktemplateRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limitexpiredays** | **Boolean** | 是否限制外链有效期 | 
**allowexpiredays** | **Long** | limitexpireday&#x3D;fasle  表示默认有效期  limitexpireday&#x3D;true  表示最大有效期 | 
**allowperm** | **Long** | 可设定的权限 | 
**defaultperm** | **Long** | 默认权限 | 
**limitaccesstimes** | **Boolean** | 是否限制打开次数 | 
**allowaccesstimes** | **Long** | limitaccesstimes&#x3D;false  表示默认打开次数  limitaccesstimes&#x3D;true  表示最大打开次数 | 
**accesspassword** | **Boolean** | 是否强制使用访问密码 | 
