# CaGetResCainfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vender** | **String** | 厂商ID |  [optional]
**description** | **String** | 厂商描述 |  [optional]
**server** | **String** | CA服务器信息 |  [optional]
**appid** | **String** | CA服务器分配的appid |  [optional]
**appkey** | **String** | CA服务器分配的appkey |  [optional]
