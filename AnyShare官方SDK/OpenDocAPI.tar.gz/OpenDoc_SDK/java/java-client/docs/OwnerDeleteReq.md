# OwnerDeleteReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档id | 
**userids** | **List&lt;String&gt;** | 用户的id数组 | 
