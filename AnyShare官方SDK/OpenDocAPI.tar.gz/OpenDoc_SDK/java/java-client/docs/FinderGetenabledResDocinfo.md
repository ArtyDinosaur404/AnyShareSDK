# FinderGetenabledResDocinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档id | 
**path** | **String** | 文档路径 | 
**size** | **Long** | 文件大小，文件夹则为-1 | 
**clientMtime** | **Long** | 如果是文件，返回由客户端设置的文件本地修改时间；若未设置，返回modified的值 | 
