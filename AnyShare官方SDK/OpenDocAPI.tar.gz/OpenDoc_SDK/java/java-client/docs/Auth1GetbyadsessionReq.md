# Auth1GetbyadsessionReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adsession** | **String** | windows ad用户登录凭据 | 
