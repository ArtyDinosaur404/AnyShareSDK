# UserGetResDirectdeptinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**depid** | **String** | 部门唯一标识 | 
**name** | **String** | 部门的显示名称 | 
