# DepartmentGetbasicinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | 部门名称 | 
**path** | **String** | 部门路径 | 
