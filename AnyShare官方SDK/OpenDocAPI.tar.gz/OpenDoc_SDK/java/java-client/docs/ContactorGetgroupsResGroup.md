# ContactorGetgroupsResGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | 分组id | 
**groupname** | **String** | 分组名 | 
**count** | **Long** | 分组下联系人个数 | 
