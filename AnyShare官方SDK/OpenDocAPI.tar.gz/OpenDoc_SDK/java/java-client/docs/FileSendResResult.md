# FileSendResResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**causemsg** | **String** | 发送成功时为空；否则为详细错误信息 | 
**msg** | **String** | 发送成功时为空；否则为错误信息 | 
**recipient** | **String** | 收件人名字 | 
**success** | **Boolean** | 发送是否成功 | 
