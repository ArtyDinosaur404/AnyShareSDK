# OwnerSetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Long** | 执行结果  0表示没有权限变化或者成功配置  1表示已提交申请 | 
