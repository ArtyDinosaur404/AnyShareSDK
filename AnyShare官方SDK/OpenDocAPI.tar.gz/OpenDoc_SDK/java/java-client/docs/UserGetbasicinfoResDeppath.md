# UserGetbasicinfoResDeppath

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deppath** | **String** | 部门路径 | 
