# FileDeletecommentReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commentid** | **Long** | 评论id（由获取文件评论协议返回） | 
**docid** | **String** | 文件gns路径（列举协议返回） | 
