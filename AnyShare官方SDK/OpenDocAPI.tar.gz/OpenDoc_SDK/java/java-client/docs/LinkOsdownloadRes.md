# LinkOsdownloadRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**needWatermark** | **Boolean** | 是否是下载水印文件 | 
**authrequest** | **List&lt;String&gt;** | - authrequest[0]：请求方法  - authrequest[1]：资源URL | 
**name** | **String** | 文件名称，UTF8编码 | 
**rev** | **String** | 文件版本号 | 
**size** | **Long** | 当前下载版本的总大小 | 
