# AuditGetpendingapprovalsResApplyinfoType2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetapplysResApplyinfoType2Detail**](AuditGetapplysResApplyinfoType2Detail.md) |  |  [optional]
