# UpdateDownloadReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**osType** | **Long** | 客户端对应的平台  2: android  3: mac  4: windows 32bit  5:windows 64bit  6: office plugin | 
**reqhost** | **String** | 从存储服务器下载数据时的请求地址 |  [optional]
**usehttps** | **Boolean** | 是否使用https下载数据，默认为true |  [optional]
