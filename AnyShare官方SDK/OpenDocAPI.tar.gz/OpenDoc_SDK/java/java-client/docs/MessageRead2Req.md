# MessageRead2Req

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgids** | **List&lt;String&gt;** | 要标记为已读的消息的id数组，前面get返回的 | 
