# MessageGetResMsgType9

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**end** | **Long** | 有效到期时间 (unix utc 精确到微秒)  -1 无限期 | 
**perm** | **Long** | 外链权限，参考外链 | 
