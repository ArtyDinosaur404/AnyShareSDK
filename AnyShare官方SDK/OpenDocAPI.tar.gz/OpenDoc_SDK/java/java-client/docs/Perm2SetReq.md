# Perm2SetReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档id | 
**perminfos** | [**List&lt;Perm2SetReqPerminfo&gt;**](Perm2SetReqPerminfo.md) | 权限配置条目数组 | 
**inherit** | **Boolean** | 启用继承：true，上级所有权限均继承  禁用继承：false，上级所有权限均不继承   | 
