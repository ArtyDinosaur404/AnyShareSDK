# AuditGetdocapprovalsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applyinfos** | [**List&lt;AuditGetdocapplysResApplyinfo&gt;**](AuditGetdocapplysResApplyinfo.md) | 申请信息 | 
