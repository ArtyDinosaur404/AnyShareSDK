# AuditPublishdocRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applyid** | **String** | 申请记录id | 
**audittype** | **Long** | 流程审核模式 | 
**result** | **String** | 操作结果 | 
