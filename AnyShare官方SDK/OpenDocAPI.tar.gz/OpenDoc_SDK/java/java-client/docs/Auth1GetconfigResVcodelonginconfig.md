# Auth1GetconfigResVcodelonginconfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isenable** | **Boolean** | 是否启用登录验证码功能 | 
**passwderrcnt** | **Long** | 达到开启登录验证码的密码出错次数 | 
