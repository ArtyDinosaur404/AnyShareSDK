# Auth1GetconfigResCsflevelenum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
