# FileGetsuggestnameRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | UTF8编码，服务端如果不存在同名的name，则直接返回name；如果存在同名的name，则根据重名冲突策略找到不冲突的文件名 | 
