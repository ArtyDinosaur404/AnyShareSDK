# SearchSearchRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | [**SearchSearchResResponse**](SearchSearchResResponse.md) |  | 
**highlighting** | [**SearchSearchResHighlighting**](SearchSearchResHighlighting.md) |  |  [optional]
