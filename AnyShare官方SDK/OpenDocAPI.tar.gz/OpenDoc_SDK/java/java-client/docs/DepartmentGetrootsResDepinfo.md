# DepartmentGetrootsResDepinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**depid** | **String** | 部门唯一标识 | 
**name** | **String** | 部门显示名 | 
**isconfigable** | **Boolean** | 是否可配置权限 | 
