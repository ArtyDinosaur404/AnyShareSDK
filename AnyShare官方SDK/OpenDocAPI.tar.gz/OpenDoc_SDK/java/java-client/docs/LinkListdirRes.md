# LinkListdirRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dirs** | [**List&lt;LinkListdirResDir&gt;**](LinkListdirResDir.md) | 文件夹信息 | 
**files** | [**List&lt;LinkListdirResFile&gt;**](LinkListdirResFile.md) | 文件信息 | 
