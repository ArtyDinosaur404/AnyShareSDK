# MessageGetResMsgType18

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **String** | 消息体 简单消息中文档相关字段全部为空 | 
