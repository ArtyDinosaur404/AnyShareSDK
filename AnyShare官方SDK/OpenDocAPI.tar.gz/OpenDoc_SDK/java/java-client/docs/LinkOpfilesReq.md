# LinkOpfilesReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 外链文件或文件夹gns路径（getlinked协议返回） | 
**start** | **Long** | 开始位置，默认为0 |  [optional]
**limit** | **Long** | 分页条数，默认为-1，返回start后面的所有记录 |  [optional]
