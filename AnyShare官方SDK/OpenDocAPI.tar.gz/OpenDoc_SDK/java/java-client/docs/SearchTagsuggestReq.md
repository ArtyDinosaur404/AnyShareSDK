# SearchTagsuggestReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Long** | 需要建议的最大返回个数，大于0，默认是10 |  [optional]
**prefix** | **String** | 需要建议的标签前缀，不能为空 | 
