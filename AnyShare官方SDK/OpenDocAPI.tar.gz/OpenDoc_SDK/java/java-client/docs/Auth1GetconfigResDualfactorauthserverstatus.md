# Auth1GetconfigResDualfactorauthserverstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authByOTP** | **Boolean** | 是否使用动态密保验证 | 
**authByUkey** | **Boolean** | 是否使用Ukey验证 | 
**authByEmail** | **Boolean** | 是否使用邮箱验证 | 
**authBySms** | **Boolean** | 是否使用短信验证 | 
