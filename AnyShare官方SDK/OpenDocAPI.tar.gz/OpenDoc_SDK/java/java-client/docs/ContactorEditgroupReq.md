# ContactorEditgroupReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupid** | **String** | 联系人组唯一标识 | 
**newname** | **String** | 联系人组新名称 | 
