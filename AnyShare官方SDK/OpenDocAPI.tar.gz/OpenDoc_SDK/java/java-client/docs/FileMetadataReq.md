# FileMetadataReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件gns路径（列举协议返回） |  [optional]
**rev** | **String** | 版本号，为空默认获取最新版本的元数据 |  [optional]
**objectid** | **String** | 文件对象id |  [optional]
