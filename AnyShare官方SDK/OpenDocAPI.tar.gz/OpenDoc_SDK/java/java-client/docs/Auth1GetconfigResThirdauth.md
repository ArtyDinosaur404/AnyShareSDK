# Auth1GetconfigResThirdauth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | 唯一第三方认证系统 | 
**config** | **Map&lt;String, Object&gt;** | 第三方认证系统的配置参数 | 
