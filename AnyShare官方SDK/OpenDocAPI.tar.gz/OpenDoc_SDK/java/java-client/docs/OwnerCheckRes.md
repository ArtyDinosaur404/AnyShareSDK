# OwnerCheckRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isowner** | **Boolean** | 是否是所有者 | 
