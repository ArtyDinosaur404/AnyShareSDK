# LinkGetinfoReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **String** | 外链唯一标识 | 
**password** | **String** | 密码 | 
**docid** | **String** | gns路径 |  [optional]
