# DirDeleteRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isdirexist** | **Boolean** | 当前文件夹最后是否还存在（用于前端判断刷新界面）   | 
