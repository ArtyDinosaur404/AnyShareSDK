# FileAttributeRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createTime** | **Long** | 返回服务器端modified的值 | 
**creator** | **String** | 文件创建者 | 
**csflevel** | **Long** | 文件密级，5~15 | 
**name** | **String** | 文件名，UTF8编码 | 
**tags** | **List&lt;String&gt;** | 文件的标签，字符串数组 | 
**uniqueid** | **String** | 对于归档库文件，返回文件唯一标识 |  [optional]
