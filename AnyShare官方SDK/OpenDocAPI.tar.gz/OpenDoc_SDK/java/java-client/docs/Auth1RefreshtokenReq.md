# Auth1RefreshtokenReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokenid** | **String** | 用户身份凭证 | 
**expirestype** | **Long** | 刷新有效期类型： expirestype等于1时，刷新后token有效期为3天； expirestype等于2时，刷新后token有效期为1年； expirestype为其他值时，抛错参数值非法。 | 
**userid** | **String** | 用户id | 
