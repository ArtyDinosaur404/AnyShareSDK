# AuditGetshareapplyhistoryRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applyinfos** | **List&lt;Object&gt;** | 申请信息 | 
