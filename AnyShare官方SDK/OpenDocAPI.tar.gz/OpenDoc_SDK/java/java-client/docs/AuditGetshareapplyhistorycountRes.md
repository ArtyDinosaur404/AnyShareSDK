# AuditGetshareapplyhistorycountRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Long** | 共享申请历史总数 | 
