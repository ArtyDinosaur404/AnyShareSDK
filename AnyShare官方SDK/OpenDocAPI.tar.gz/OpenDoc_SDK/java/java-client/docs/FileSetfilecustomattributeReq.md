# FileSetfilecustomattributeReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件gns路径 |  [optional]
**attribute** | [**List&lt;FileSetfilecustomattributeReqAttribute&gt;**](FileSetfilecustomattributeReqAttribute.md) | 属性值数组 | 
