# Perm1CheckallRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowvalue** | **Long** | 允许的权限值 | 
**denyvalue** | **Long** | 拒绝的权限值 | 
