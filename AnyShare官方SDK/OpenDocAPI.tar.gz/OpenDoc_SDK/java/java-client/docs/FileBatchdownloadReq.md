# FileBatchdownloadReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | zip压缩包名称 | 
**reqhost** | **String** | 从存储服务器下载数据时的请求地址 | 
**usehttps** | **Boolean** | 上传是否使用https，默认为true |  [optional]
**files** | **List&lt;String&gt;** | 文件GNS数组 |  [optional]
**dirs** | **List&lt;String&gt;** | 文件夹GNS数组 |  [optional]
