# MessageGetResMsgType23

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**antivirusadmin** | **String** | 防病毒管理员 | 
**antivirusop** | **Long** | 杀毒类型   1 表示隔离  2表示修复 | 
