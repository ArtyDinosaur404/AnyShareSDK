# AutolockRefreshRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lockinfos** | [**List&lt;AutolockRefreshResLockinfo&gt;**](AutolockRefreshResLockinfo.md) | 文件锁刷新后的状态 | 
