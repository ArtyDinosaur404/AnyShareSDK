# ContactorSearchpersonsResUserinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **String** | 用户名 | 
**groupid** | **String** | 联系人组id | 
**groupname** | **String** | 联系人组名 | 
**name** | **String** | 显示名 | 
**userid** | **String** | 用户id | 
