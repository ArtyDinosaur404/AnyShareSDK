# AuditGetshareapplyhistoryResApplyinfoType6Detail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auditmsg** | **String** | 审核说明 | 
**inherit** | **Boolean** | 是否启用继承  false表示禁用  true表示启用 | 
