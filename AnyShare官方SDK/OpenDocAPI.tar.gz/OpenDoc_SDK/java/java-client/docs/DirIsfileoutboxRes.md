# DirIsfileoutboxRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isfileoutbox** | **Boolean** | 是否是发件箱 | 
