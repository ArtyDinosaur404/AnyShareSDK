# DirSizeReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 目录/文件gns路径（列举协议返回） | 
**onlyrecycle** | **Boolean** | - 默认为false  - 对于非顶级目录，参数onlyrecycle无影响  - 对顶级目录： 如果为false，统计整个顶级目录的大小；如果为true，只统计其中回收站的大小   |  [optional]
