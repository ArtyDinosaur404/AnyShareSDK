# DirSetcsflevelRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Long** | 0表示没有密级变化或者成功设置； 1表示申请已提交 | 
