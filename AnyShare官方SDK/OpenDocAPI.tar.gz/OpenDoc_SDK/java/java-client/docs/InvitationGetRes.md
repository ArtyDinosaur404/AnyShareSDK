# InvitationGetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**invitationendtime** | **Long** | 邀请链接到期时间，如果为-1，表示无限期 | 
**perm** | **Long** | 权限值 | 
**permendtime** | **Long** | 权限到期时间，如果为-1，表示无限期 | 
**image** | **String** | 图片备注信息 | 
**description** | **String** | 备注描述信息 | 
**docname** | **String** | 文档名称 | 
**isdir** | **Boolean** | 是否为目录 | 
