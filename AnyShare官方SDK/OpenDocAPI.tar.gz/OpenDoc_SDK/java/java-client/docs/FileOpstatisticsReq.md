# FileOpstatisticsReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **List&lt;String&gt;** | 文件gns路径（列举协议返回） | 
