# AuditGetshareapprovehistoryResApplyinfoType2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | [**AuditGetshareapplyhistoryResApplyinfoType2Detail**](AuditGetshareapplyhistoryResApplyinfoType2Detail.md) |  |  [optional]
