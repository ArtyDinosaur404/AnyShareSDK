# DepartmentGetrootsRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**depinfos** | [**List&lt;DepartmentGetrootsResDepinfo&gt;**](DepartmentGetrootsResDepinfo.md) | 部门信息 |  [optional]
