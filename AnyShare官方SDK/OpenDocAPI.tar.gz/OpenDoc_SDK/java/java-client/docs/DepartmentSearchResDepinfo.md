# DepartmentSearchResDepinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**depid** | **String** | 部门唯一标识 | 
**name** | **String** | 部门显示名 | 
**path** | **String** | 部门路径 | 
