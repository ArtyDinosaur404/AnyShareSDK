# LinkCheckpermReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **String** | 外链唯一标识，如FC5E038D38A57032085441E7FE7010B0 | 
**password** | **String** | 密码 | 
**perm** | **Long** | 权限值，值域为1、2、4，具体说明参见开启外链中的描述 | 
