# Entrydoc2GetmanagedResDocinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档库id | 
**doctype** | **Long** | 文档库类型：  1：个人文档库  2：个人群组文档库  3：自定义文档库  4：共享个人文档库  5：归档库  6：共享个人群组文档库   | 
**name** | **String** | 文档库名称 | 
**rev** | **String** | 文件库变化标识 | 
**size** | **Long** | -1表示文件夹 | 
**typename** | **String** | 文档类型名称 | 
