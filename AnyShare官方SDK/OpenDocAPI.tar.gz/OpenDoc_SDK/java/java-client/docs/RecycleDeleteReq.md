# RecycleDeleteReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 要删除的文件/目录在回收站的gns路径 | 
