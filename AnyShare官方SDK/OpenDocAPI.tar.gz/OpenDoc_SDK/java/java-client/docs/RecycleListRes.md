# RecycleListRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dirs** | [**List&lt;RecycleListResDirs&gt;**](RecycleListResDirs.md) | 文件夹信息 |  [optional]
**files** | [**List&lt;RecycleListResFiles&gt;**](RecycleListResFiles.md) | 文件信息 |  [optional]
**servertime** | **Long** | 服务器时间，用来计算保留时间 | 
