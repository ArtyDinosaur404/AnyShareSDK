# DepartmentGetsubusersRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userinfos** | [**List&lt;DepartmentGetsubusersResUserinfo&gt;**](DepartmentGetsubusersResUserinfo.md) | 用户信息 | 
