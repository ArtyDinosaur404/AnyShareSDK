# Perm1CheckReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档id | 
**perm** | **Long** | 权限值，这里只能是1,2,4,8,16,32,64 | 
