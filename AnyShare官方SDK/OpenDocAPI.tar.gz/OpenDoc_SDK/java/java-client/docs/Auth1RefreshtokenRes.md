# Auth1RefreshtokenRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires** | **Long** | 刷新以后token的有效期，单位为秒 | 
