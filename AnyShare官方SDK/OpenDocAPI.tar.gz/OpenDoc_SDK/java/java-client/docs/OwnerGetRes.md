# OwnerGetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ownerinfos** | [**List&lt;OwnerGetResOwnerinfo&gt;**](OwnerGetResOwnerinfo.md) | 多个所有者信息 | 
