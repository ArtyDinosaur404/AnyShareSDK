# Auth1ValidatesecuritydeviceReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thirdpartyid** | **String** | 标识第三方认证类型 | 
**params** | **Map&lt;String, Object&gt;** | 第三方认证信息 | 
