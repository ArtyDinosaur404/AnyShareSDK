# Auth1LogoutReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ostype** | **Long** | 操作系统类型    0: Unknown    1: Ios    2: Android    3: Windows phone    4: Windows    5: MacOSX    6: Web    7: Mobile Web    8: NAS  | 
