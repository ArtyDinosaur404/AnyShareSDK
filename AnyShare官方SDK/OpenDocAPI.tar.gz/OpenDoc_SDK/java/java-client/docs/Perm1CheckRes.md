# Perm1CheckRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Long** | 0表示OK  1表示未配置该权限  2表示拒绝该权限 | 
