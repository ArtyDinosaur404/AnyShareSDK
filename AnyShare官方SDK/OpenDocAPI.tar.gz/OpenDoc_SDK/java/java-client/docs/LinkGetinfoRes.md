# LinkGetinfoRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | 文件或文件夹名 | 
**modified** | **Long** | 修改时间 | 
**size** | **Long** | 文件大小，文件夹为-1 | 
**site** | **String** | 站点名 | 
