# FileConvertpathRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**namepath** | **String** | 名字路径 | 
