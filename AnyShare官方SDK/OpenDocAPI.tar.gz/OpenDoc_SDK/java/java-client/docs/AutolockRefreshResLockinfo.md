# AutolockRefreshResLockinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文件id | 
**state** | **Long** | state等于0时表示刷新成功  state等于1表示发生异常 | 
**errmsg** | **String** | 异常内容，state等于1时会填充该字段 |  [optional]
