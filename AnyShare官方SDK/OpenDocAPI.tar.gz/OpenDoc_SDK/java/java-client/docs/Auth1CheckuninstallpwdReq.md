# Auth1CheckuninstallpwdReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uninstallpwd** | **String** | 卸载口令 | 
