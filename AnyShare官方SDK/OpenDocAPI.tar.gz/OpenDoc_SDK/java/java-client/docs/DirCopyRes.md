# DirCopyRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 返回复制后的gns路径 | 
**name** | **String** | UTF8编码，仅当ondup为2时才返回，否则返回参数仍然为空 |  [optional]
**id** | **String** | 发起复制任务后，返回任务ID,用于查询复制任务进度信息 | 
