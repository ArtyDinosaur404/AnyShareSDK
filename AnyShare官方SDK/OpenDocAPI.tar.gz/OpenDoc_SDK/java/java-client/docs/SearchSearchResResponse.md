# SearchSearchResResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**next** | **String** | 返回下次发起请求的start | 
**docs** | [**List&lt;SearchSearchResResponseDoc&gt;**](SearchSearchResResponseDoc.md) | 返回各个文档的信息 | 
**hits** | **Long** | 返回检索命中总数（查询第一页时返回） |  [optional]
