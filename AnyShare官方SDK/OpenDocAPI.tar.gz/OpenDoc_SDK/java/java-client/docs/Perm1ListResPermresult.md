# Perm1ListResPermresult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessorid** | **String** | 访问者id | 
**accessortype** | [**AccessortypeEnum**](#AccessortypeEnum) | 访问者类型 | 
**accessorname** | **String** | 访问者的名称 | 
**allowvalue** | **Long** | 允许的权限值 | 
**denyvalue** | **Long** | 拒绝的权限值 | 

<a name="AccessortypeEnum"></a>
## Enum: AccessortypeEnum
Name | Value
---- | -----
USER | &quot;user&quot;
DEPARTMENT | &quot;department&quot;
CONTACTOR | &quot;contactor&quot;
