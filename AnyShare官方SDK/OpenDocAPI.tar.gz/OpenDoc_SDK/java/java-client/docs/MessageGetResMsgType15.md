# MessageGetResMsgType15

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docaudittype** | **Long** | 审核模式 | 
**previousauditor** | **String** | 上一级审核员名称，如果为“”，表示没有上级审核员 | 
**processname** | **String** | 文档流程名称 | 
**requestername** | **String** | 流程申请者名称 | 
