# MessageGetResMsgType13

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auditorname** | **String** | 审核员名字 | 
**auditresult** | **Boolean** | 审核结果 true表示通过 false表示拒绝 | 
**auditmsg** | **String** | 审核意见 | 
