# Auth1RevoketokenReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokenid** | **String** | 用户身份凭证 | 
