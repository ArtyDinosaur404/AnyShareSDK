# DirAttributeRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createTime** | **Long** | 目录创建的服务端时间 | 
**creator** | **String** | 目录创建者 | 
**modified** | **Long** | 目录的修改时间 | 
**name** | **String** | 目录名，UTF8编码 | 
**tags** | **List&lt;String&gt;** | 目录的标签，字符串数组 | 
