# FileOscompleteuploadReqPartinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
