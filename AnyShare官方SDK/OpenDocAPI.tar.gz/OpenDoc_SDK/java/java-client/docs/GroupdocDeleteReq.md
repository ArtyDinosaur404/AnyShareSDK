# GroupdocDeleteReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 群组对应的文档id | 
