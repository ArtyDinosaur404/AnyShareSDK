# FilePreduploadRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**match** | **Boolean** | 是否有可能存在 | 
