# OwnerSetReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档id | 
**userconfigs** | [**List&lt;OwnerSetReqUserconfig&gt;**](OwnerSetReqUserconfig.md) | 所有者数组 | 
