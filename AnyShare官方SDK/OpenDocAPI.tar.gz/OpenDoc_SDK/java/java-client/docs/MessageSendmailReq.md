# MessageSendmailReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mailto** | **List&lt;String&gt;** | 收件人邮箱地址列表 | 
**subject** | **String** | 邮件主题 |  [optional]
**content** | **String** | 邮件内容（由html格式组织） |  [optional]
