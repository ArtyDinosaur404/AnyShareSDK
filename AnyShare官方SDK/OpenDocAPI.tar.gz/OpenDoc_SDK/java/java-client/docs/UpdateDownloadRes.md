# UpdateDownloadRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**URL** | **String** | 客户端升级包的下载链接 | 
