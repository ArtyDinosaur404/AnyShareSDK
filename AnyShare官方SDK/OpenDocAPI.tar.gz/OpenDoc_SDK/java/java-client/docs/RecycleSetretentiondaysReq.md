# RecycleSetretentiondaysReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 个人文档或者文档库的gns路径 | 
**days** | **Long** | 保留天数 | 
