# DepartmentSearchResUserInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userid** | **String** | 用户唯一标识 | 
**account** | **String** | 用户登录账号 | 
**name** | **String** | 用户显示名 | 
**mail** | **String** | 用户邮箱地址 | 
**csflevel** | **Long** | 用户密级，5~15 | 
**depid** | **String** | 用户直属部门id | 
**depname** | **String** | 用户直属部门名称 | 
**deppath** | **String** | 部门路径 | 
