# RecycleGetretentiondaysRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days** | **Long** | 保留天数 | 
