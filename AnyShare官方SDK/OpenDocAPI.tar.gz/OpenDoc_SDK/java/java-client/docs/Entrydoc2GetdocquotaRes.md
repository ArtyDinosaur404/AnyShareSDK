# Entrydoc2GetdocquotaRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quota** | **Long** | 配额 | 
**used** | **Long** | 已用空间 | 
