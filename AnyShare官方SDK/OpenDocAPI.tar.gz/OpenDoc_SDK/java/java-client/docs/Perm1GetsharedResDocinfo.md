# Perm1GetsharedResDocinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 文档id | 
**path** | **String** | 文档路径 | 
**size** | **Long** | 文件大小，文件夹则为-1 | 
**clientMtime** | **Long** | 如果是文件，返回由客户端设置的文件本地修改时间；若未设置，返回modified的值 | 
**accessorNames** | **String** | 访问者名称，存在多个访问者时用\&quot;,\&quot;进行分隔 | 
