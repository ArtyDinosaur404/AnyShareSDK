# RecycleGetsuggestnameReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 要还原的文件/目录在回收站的gns路径（可以是回收站的子目录或者子文件） | 
