# Auth1GetvcodeReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uuid** | **String** | 上一条验证码的唯一标识 | 
