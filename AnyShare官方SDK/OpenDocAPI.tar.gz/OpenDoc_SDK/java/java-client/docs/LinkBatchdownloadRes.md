# LinkBatchdownloadRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**method** | **String** | url请求方法 | 
**url** | **String** | 文件批量下载地址 | 
