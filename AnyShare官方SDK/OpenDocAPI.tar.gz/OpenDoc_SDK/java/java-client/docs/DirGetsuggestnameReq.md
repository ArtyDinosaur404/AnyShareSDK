# DirGetsuggestnameReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 父目录的gns路径 | 
**name** | **String** | UTF-8编码，要上传的目录名 | 
