# MessageGetResMsgType21

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creator** | **String** | 创建者 | 
**modifier** | **String** | 修改者 | 
**quarantinetype** | **Long** | 被隔离类型：1：非法 2：染毒 3：涉黄 | 
**processtype** | **Long** | 处理类型：0：隔离 1：修复（还原消息无需使用） | 
