# RecycleListResDirs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 回收站中文件/目录的gns路径 | 
**editor** | **String** | 回收站中文件/目录删除者的名称 | 
**modified** | **Long** | 回收站中文件/目录的删除时间 | 
**name** | **String** | 回收站中文件/目录的名称，UTF8编码 | 
**path** | **String** | 回收站中文件/目录的原路径，UTF8编码 | 
**size** | **Long** | 回收站中文件的大小，目录大小为-1 | 
