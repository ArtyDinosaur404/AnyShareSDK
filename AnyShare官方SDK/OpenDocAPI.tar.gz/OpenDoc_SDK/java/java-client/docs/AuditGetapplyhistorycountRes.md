# AuditGetapplyhistorycountRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Long** | 流程申请历史总数 | 
