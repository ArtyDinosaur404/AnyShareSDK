# GroupdocAddReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | 新建群组的名称 | 
**quota** | **Long** | 新建群组的配额 | 
