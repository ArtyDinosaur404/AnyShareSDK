# InvitationJoinRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docname** | **String** | 文档内链地址 | 
**result** | **Boolean** | 本次加入是否成功 | 
