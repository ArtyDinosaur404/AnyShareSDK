# Entrydoc2GetuserquotaRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quotainfos** | [**List&lt;Entrydoc2GetuserquotaResQuotainfo&gt;**](Entrydoc2GetuserquotaResQuotainfo.md) | 表示多个配额信息 | 
