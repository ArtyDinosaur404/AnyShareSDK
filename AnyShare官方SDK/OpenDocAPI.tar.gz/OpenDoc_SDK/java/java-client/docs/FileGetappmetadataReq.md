# FileGetappmetadataReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appid** | **String** | 应用 id，由控制台配置后分配 | 
**docid** | **String** | 文件gns路径（列举协议返回） | 
