# AuditGetapplyhistoryRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applyinfos** | [**List&lt;AuditGetapplyhistoryResApplyinfo&gt;**](AuditGetapplyhistoryResApplyinfo.md) | 申请信息 | 
