# LinkGetlinkedResItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 外链访问的文件gns路径 | 
**namepath** | **String** | 外链访问的文件name路径 | 
**size** | **Long** | 外链访问的文件大小 | 
**modified** | **Long** | 外链访问的文件最后修改时间 | 
