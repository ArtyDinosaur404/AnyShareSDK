# UserAgreedtotermsofuseRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **String** | 执行结果  ok 表示同意使用协议 | 
