# Perm2GetRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**perminfos** | [**List&lt;Perm2GetResPerminfo&gt;**](Perm2GetResPerminfo.md) | 权限配置条目数组 | 
**inherit** | **Boolean** | 启用继承：true，上级所有权限对该对象及下级对象有效  禁用继承：false，上级所有权限对该对象及下级对象无效 | 
