# DirListRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dirs** | [**List&lt;DirListResDir&gt;**](DirListResDir.md) | 文件夹信息 | 
**files** | [**List&lt;DirListResFile&gt;**](DirListResFile.md) | 文件信息 | 
