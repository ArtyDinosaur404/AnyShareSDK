# PkiAuthenReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** | 通过pki?method&#x3D;original获取的值 | 
**detach** | **String** | 使用key与original计算后的值 | 
