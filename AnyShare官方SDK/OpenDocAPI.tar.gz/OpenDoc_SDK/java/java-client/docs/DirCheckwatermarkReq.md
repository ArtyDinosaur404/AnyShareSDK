# DirCheckwatermarkReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 目录gns路径 | 
