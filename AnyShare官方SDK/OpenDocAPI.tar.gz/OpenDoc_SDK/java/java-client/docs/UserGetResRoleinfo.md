# UserGetResRoleinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | 角色id | 
**name** | **String** | 角色名称 | 
