# Entrydoc2GetReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doctype** | **Long** | 文档库类型：  0：所有类型  1：个人文档库  2：个人群组文档库  3：自定义文档库  4：共享个人文档库  5：归档库  6：共享个人群组文档库 | 
