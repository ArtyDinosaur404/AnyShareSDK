# Auth1ValidatesecuritydeviceRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Boolean** | 是否认证成功 | 
