# DirCreatemultileveldirRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docid** | **String** | 创建的多级目录最后一级的gns路径 | 
**rev** | **String** | 数据变化标识 | 
**modified** | **Long** | 创建时间，UTC时间，此为服务器时间 | 
