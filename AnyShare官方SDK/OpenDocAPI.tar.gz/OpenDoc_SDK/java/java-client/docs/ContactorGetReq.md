# ContactorGetReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupid** | **String** | 分组id | 
