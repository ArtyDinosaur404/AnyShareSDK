# **说明**

- 本路径下存放的是 OpenDoc API 文档，文档格式为 ".html"。
- 用户通过 OpenDoc API 文档能够非常直观地获取 OpenDoc API 的具体信息(包括请求url，请求参数，返回参数，参数说明等等)。
- 用户可配合 OpenDoc API 文档便捷地使用提供的SDK(上级目录/OpenDoc_SDK)来调用指定的 OpenDoc API。SDK的具体用法请参考提供的Demo(上级目录/demo)。

