# **项目环境**

**IDE：**eclipse: Mars.2 Release (4.5.2)
**JDK：**jdk1.8.0_181

# **重要说明**

1. OpenDoc_API-文档访问.html为API说明文档，编写API代码时请参照该文档。
2. 项目名为EASFramework，提供API调用框架和示例demo(文件上传，文件分块上传，文件下载，缩略图，设置/获取自定义属性，获取消息通知)。用户可直接使用eclipse导入使用。
3. 项目为基本java项目，导入了需要的jar包。已提供基本框架，其并没有使用第三方框架(如maven,spring等)，用户可直接使用提供框架，也可将其集成到自己的开发框架中。
4. 框架中main.framework.conf 下的 LoginInfo.java文件为配置文件，使用前请先更改配置信息。
5. 框架中main.framework.service.impl 下的 FileUploadServiceImpl文件为对OpenDocAPI的二层封装，现已实现单文件上传和分块上传。
6. 框架中main.framework.controller 下的 FileController 文件提供了Demo案例，可直接运行其中的main函数进行测试。
7. [下载文件] 关于使用HTTP Range头进行分块下载文件，请参考：https://www.cnblogs.com/1995hxt/p/5692050.html。
8. [上传文件] 不同存储可能有不同的最大分块数量、最小分块大小等限制，具体限制见"OpenDoc_API-文档访问.html"的 osoption API 返回参数。具体如何实现自动判断划分块大小请参考框架中关于"分块上传"的实现。

