package main.framework.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import io.openDocAPI.client.ApiException;
import io.openDocAPI.client.api.DefaultApi;
import io.openDocAPI.client.model.FileGetfilecustomattributeReq;
import io.openDocAPI.client.model.FileGetfilecustomattributeResItem;
import io.openDocAPI.client.model.FileGetinfobypathReq;
import io.openDocAPI.client.model.FileSetfilecustomattributeReq;
import io.openDocAPI.client.model.FileSetfilecustomattributeReqAttribute;
import io.openDocAPI.client.model.MessageGetReq;
import io.openDocAPI.client.model.MessageGetRes;
import io.openDocAPI.client.model.MessageGetResMsgBase;
import io.openDocAPI.client.model.MessageGetResMsgType1;
import io.openDocAPI.client.model.MessageGetResMsgType2;
import io.openDocAPI.client.model.MessageGetResMsgType3;
import io.openDocAPI.client.model.MessageGetResMsgType5;
import io.openDocAPI.client.model.MessageGetResMsgType7;
import io.openDocAPI.client.model.MessageGetResMsgType9;
import main.framework.model.MultiUploadReq;
import main.framework.model.SingleDownloadReq;
import main.framework.model.SingleUploadReq;
import main.framework.service.FileUploadDownloadService;
import main.framework.service.impl.FileUploadDownloadServiceImpl;
import main.framework.util.APIInstanceManager;
import main.framework.util.OSSException;

public class FileController {

    private FileUploadDownloadService fileUploadService;
    private APIInstanceManager apiInstceManager;

    public static void main(String[] args) throws Exception {

        FileController controller = new FileController();
        // controller.thumbnailDemo(); //缩略图Demo
        // controller.fileSingleUploadDemo(); //文件上传Demo
        // controller.fileMultiUploadDemo(); //文件分块上传Demo
        // controller.setfilecustomattributeDemo(); //设置自定义属性Demo
        // controller.getfilecustomattributeDemo(); //获取自定义属性Demo
        // controller.fileSingleDownloadDemo(); // 文件下载Demo
        controller.getMessageDemo(); //获取消息通知Demo
    }

    public FileController() throws Exception {
        apiInstceManager = new APIInstanceManager();
        fileUploadService = new FileUploadDownloadServiceImpl(apiInstceManager);
    }

    public void fileSingleUploadDemo() {
        // 设置传参
        SingleUploadReq body = new SingleUploadReq();
        // String filePath = "/root/PremiumSoft.zip";
        String filePath = "D:/PremiumSoft.zip";
        String parentId = getDocidByPath("test/测试");
        body.setDocid(parentId);
        body.setFilePath(filePath);
        body.setOndup(2L);

        // 调用接口
        try {
            fileUploadService.singleUpload(body);
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
            e.printStackTrace();
        } catch (OSSException e) {
            System.out.println(e.getErrCode() + " " + e.getErrBody() + " " + e.getErrHeaders());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fileMultiUploadDemo() throws Exception {
        // 设置传参
        MultiUploadReq body = new MultiUploadReq();
        String parentId = getDocidByPath("test/测试");
        // String filePath = "/root/eclipse.zip";
        String filePath = "D:/eclipse.zip";
        body.setDocid(parentId);
        body.setFilePath(filePath);
        body.setOndup(2L);

        // 调用接口
        try {
            fileUploadService.multiUpload(body);
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
            e.printStackTrace();
        } catch (OSSException e) {
            System.out.println(e.getErrCode() + " " + e.getErrBody() + " " + e.getErrHeaders());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fileSingleDownloadDemo() {
        // 设置传参
        SingleDownloadReq body = new SingleDownloadReq();
        // String filePath = "/root";
        String savePath = "D:/";
        String docid = getDocidByPath("test/测试/eclipse.zip");
        body.setDocid(docid);
        body.setSavePath(savePath);
        body.setUsehttps(false);

        // 调用接口
        try {
            fileUploadService.singleDownload(body);
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
            e.printStackTrace();
        } catch (OSSException e) {
            System.out.println(e.getErrCode() + " " + e.getErrBody() + " " + e.getErrHeaders());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void thumbnailDemo() throws Exception {
        DefaultApi apiInstance = apiInstceManager.getAPIInstanceWithoutToken();
        // 设置参数
        String docid = getDocidByPath("test/road-train-landscape-storm-thumb.jpg");
        // String savePath = "/root/";
        String savePath = "D:/";

        // 调用API，在制定路径下生成缩略图片
        try {
            File result = apiInstance.fileThumbnailGet(docid, 100L, 200L,
                    apiInstceManager.getTokenManager().getTokenId(), null, 75L);
            if (savePath == null || savePath.isEmpty()) {
                result.renameTo(new File(result.getAbsolutePath() + ".jpg"));
                System.out.println(result.getAbsolutePath() + ".jpg");
            } else {
                File fnewpath = new File(savePath);
                if (!fnewpath.exists()) {
                    fnewpath.mkdirs();
                }
                File fnew = new File(savePath + "\\" + result.getName() + ".jpg");
                result.renameTo(fnew);
                System.out.println(fnew.getAbsolutePath());
            }
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setfilecustomattributeDemo() throws Exception {
        DefaultApi apiInstance = apiInstceManager.getAPIInstanceWithoutToken();
        // 设置参数
        FileSetfilecustomattributeReq body = new FileSetfilecustomattributeReq();
        String docid = getDocidByPath("test/road-train-landscape-storm-thumb.jpg");
        body.setDocid(docid);
        ArrayList<FileSetfilecustomattributeReqAttribute> attribute = new ArrayList<FileSetfilecustomattributeReqAttribute>();
        FileSetfilecustomattributeReqAttribute element1 = new FileSetfilecustomattributeReqAttribute();
        element1.setId(1L);
        element1.setValue(2233);
        attribute.add(element1);
        FileSetfilecustomattributeReqAttribute element2 = new FileSetfilecustomattributeReqAttribute();
        element2.setId(3L);
        element2.setValue(88);
        attribute.add(element2);
        FileSetfilecustomattributeReqAttribute element3 = new FileSetfilecustomattributeReqAttribute();
        element3.setId(7L);
        element3.setValue("hi");
        attribute.add(element3);
        FileSetfilecustomattributeReqAttribute element4 = new FileSetfilecustomattributeReqAttribute();
        element4.setId(9L);
        element4.setValue(3);
        attribute.add(element4);
        FileSetfilecustomattributeReqAttribute element5 = new FileSetfilecustomattributeReqAttribute();
        element5.setId(11L);
        element5.setValue(new int[] { 5, 7 });
        attribute.add(element5);
        body.setAttribute(attribute);
        try {
            apiInstance.fileSetfilecustomattributePost(body);
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
        }
    }

    public void getfilecustomattributeDemo() throws Exception {
        DefaultApi apiInstance = apiInstceManager.getAPIInstanceWithoutToken();
        // 设置参数
        FileGetfilecustomattributeReq body = new FileGetfilecustomattributeReq();
        String docid = getDocidByPath("test/road-train-landscape-storm-thumb.jpg");
        body.setDocid(docid);
        try {
            List<FileGetfilecustomattributeResItem> result = apiInstance.fileGetfilecustomattributePost(body);
            System.out.println(result);
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
        }
    }

    public void getMessageDemo() throws Exception {
        DefaultApi apiInstance = apiInstceManager.getAPIInstanceWithToken();
        //设置参数
        MessageGetReq body = new MessageGetReq();

        //调用API,根据返回消息类型来分别处理
        try {
            MessageGetRes result = apiInstance.messageGetPost(body);
            for(Object node : result.getMsgs()){
                Gson gson = new Gson();
                String json = gson.toJson(node);
                MessageGetResMsgBase base = gson.fromJson(json,MessageGetResMsgBase.class);
                int type = base.getType().intValue();
                
                switch (type){
                    case 1:
                        MessageGetResMsgType1 node1 = gson.fromJson(json,MessageGetResMsgType1.class);
                        System.out.println(node1);
                        break;
                    case 2:
                        MessageGetResMsgType2 node2 = gson.fromJson(json,MessageGetResMsgType2.class);
                        System.out.println(node2);
                        break;
                    case 3:
                        MessageGetResMsgType3 node3 = gson.fromJson(json,MessageGetResMsgType3.class);
                        System.out.println(node3);
                        break;
                    case 5:
                        MessageGetResMsgType5 node5 = gson.fromJson(json,MessageGetResMsgType5.class);
                        System.out.println(node5);
                        break;
                    case 7:
                        MessageGetResMsgType7 node7 = gson.fromJson(json,MessageGetResMsgType7.class);
                        System.out.println(node7);
                        break;
                    case 9:
                        MessageGetResMsgType9 node9 = gson.fromJson(json,MessageGetResMsgType9.class);
                        System.out.println(node9);
                        break;
                    default:
                        System.out.println("未经处理的类型 apptype：" + type);
                        break;
                }

            }
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private String getDocidByPath(String namePath) {
        DefaultApi apiInstance = apiInstceManager.getAPIInstanceWithoutToken();
        FileGetinfobypathReq getinfobypathBody = new FileGetinfobypathReq();
        getinfobypathBody.setNamepath(namePath);
        String docId = "";
        try {
            docId = apiInstance.fileGetinfobypathPost(getinfobypathBody).getDocid();
        } catch (ApiException e) {
            System.out.println(e.getCode() + " " + e.getResponseBody() + " " + e.getResponseHeaders());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return docId;
    }
}
