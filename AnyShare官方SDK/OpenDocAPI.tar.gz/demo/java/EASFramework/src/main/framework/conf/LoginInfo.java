package main.framework.conf;

public class LoginInfo {

    public final static String hostIp = "xxx.xxx.xxx.xxx";
    public final static int port = 443;
    public final static String userName = "userName";
    public final static String password = "password";

}
