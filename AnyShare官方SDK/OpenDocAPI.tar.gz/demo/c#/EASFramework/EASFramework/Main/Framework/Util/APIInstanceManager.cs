﻿using EASFramework.Main.Framework.Conf;
using IO.OpenDocAPI.Api;
using IO.OpenDocAPI.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EASFramework.Main.Framework.Util
{
    class APIInstanceManager
    {
        private DefaultApi apiInstanceWithToken;
        private DefaultApi apiInstanceWithoutToken;
        private TokenManager tokenManager;

        public DefaultApi ApiInstanceWithToken
        {
            get
            {
                return apiInstanceWithToken;
            }

        }

        public DefaultApi ApiInstanceWithoutToken
        {
            get
            {
                return apiInstanceWithoutToken;
            }
        }

        internal TokenManager TokenManager
        {
            get
            {
                return tokenManager;
            }
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        public APIInstanceManager()
        {
            tokenManager = new TokenManager();

            String basePath = "https://" + LoginInfo.hostIp + ":" + LoginInfo.port + "/api/v1";
            Configuration.Default.BasePath = basePath;
            Configuration.Default.SetVerifyingSsl(false);
            apiInstanceWithoutToken = new DefaultApi(Configuration.Default);

            Configuration.Default.AccessToken = tokenManager.TokenId;
            apiInstanceWithToken = new DefaultApi(Configuration.Default);            
        }
        // 注意：这里使用的 Configuration.Default 类型为 static Configuration. 故在多线程处理中可能会引发配置值混乱问题，建议在多线程情况下单独实例化一个Configuration来处理。代码示例如下：
        //Configuration config = new Configuration();
        //config.BasePath = basePath;
        //config.SetVerifyingSsl(false);
        //apiInstanceWithoutToken = new DefaultApi(config);

        //config.AccessToken = tokenManager.TokenId;
        //apiInstanceWithToken = new DefaultApi(config);
    }
}
