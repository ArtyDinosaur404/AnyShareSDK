﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EASFramework.Main.Framework.Model;
using EASFramework.Main.Framework.Util;
using IO.OpenDocAPI.Api;
using IO.OpenDocAPI.Model;
using System.IO;
using System.Net;
using IO.OpenDocAPI.Client;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using RestSharp;

namespace EASFramework.Main.Framework.Service.Impl
{
    class FileUploadDownloadServiceImpl : FileUploadDownloadService
    {
        private OSSHelper ossHttpHelper;
        private APIInstanceManager apiInstceManager;
        private long minSize; // 分块上传块最小单位大小。

        public FileUploadDownloadServiceImpl(APIInstanceManager apiInstceManager)
        {
            ossHttpHelper = new OSSHelper();
            this.apiInstceManager = apiInstceManager;
            MinSize = 4 * 1024 * 1024; // 默认为4M
        }

        public long MinSize
        {
            get
            {
                return minSize;
            }

            set
            {
                minSize = value;
            }
        }

        public void SingleDownload(SingleDownloadReq downloadReq)
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithToken;

            // 调用 osdownload API
            FileOsdownloadReq osdownloadBody = new FileOsdownloadReq();
            osdownloadBody = downloadReq;
            FileOsdownloadRes osdownloadResult = apiInstance.FileOsdownloadPost(osdownloadBody);
            Console.WriteLine(osdownloadResult);

            // 根据服务器返回的对象存储请求，向对象存储下载数据
            String filePath = downloadReq.SavePath + "\\" + osdownloadResult.Name;

            if (!Directory.Exists(downloadReq.SavePath))
            {
                //如果不存在，创建它
                Directory.CreateDirectory(downloadReq.SavePath);
            }
            if (File.Exists(filePath))
            {
                throw new Exception("下载路径存在同名文件，下载失败。");
            }

            List<String> headers = new List<String>();
            List<String> authRequestList = osdownloadResult.Authrequest;
            for (int i = 2; i < authRequestList.Count; ++i)
            {
                String header = authRequestList[i];
                headers.Add(header);
            }
            HttpWebResponse ossResult = ossHttpHelper.SendReqToOSS(authRequestList[0], authRequestList[1], headers, null);

            //写入数据
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {

                Stream fileContent = ossResult.GetResponseStream();
                const int bufferLen = 4096;
                byte[] buffer = new byte[bufferLen];
                int count = 0;
                while ((count = fileContent.Read(buffer, 0, bufferLen)) > 0)
                {
                    fs.Write(buffer, 0, count);
                }
            }
        }

        public void SingleUpload(SingleUploadReq uploadReq)
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithToken;

            // 调用 osbeginupload API
            FileInfo fi = new FileInfo(uploadReq.FilePath);
            uploadReq.Length = fi.Length;
            uploadReq.Name = fi.Name;
            FileOsbeginuploadReq osbeginuploadBody = new FileOsbeginuploadReq();
            osbeginuploadBody = uploadReq;

            FileOsbeginuploadRes osbeginuploadResult = apiInstance.FileOsbeginuploadPost(osbeginuploadBody);
            Console.WriteLine(osbeginuploadResult);

            // 根据服务器返回的对象存储请求，向对象存储上传数据
            byte[] body = CommonUtil.FileToBytes(uploadReq.FilePath);
            List<String> headers = new List<String>();
            List<String> authRequestList = osbeginuploadResult.Authrequest;
            for (int i = 2; i < authRequestList.Count; ++i)
            {
                String header = authRequestList[i];
                headers.Add(header);
            }
            ossHttpHelper.SendReqToOSS(authRequestList[0], authRequestList[1], headers, body);

            // 调用osendupload API
            FileOsenduploadReq osenduploadBody = new FileOsenduploadReq();
            osenduploadBody.Docid = osbeginuploadResult.Docid;
            osenduploadBody.Rev = osbeginuploadResult.Rev;
            FileOsenduploadRes osenduploadResult = apiInstance.FileOsenduploadPost(osenduploadBody);
            Console.WriteLine(osenduploadResult);
        }

        public void MultiUpload(MultiUploadReq multiUploadReq)
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithToken;
            if (!File.Exists(multiUploadReq.FilePath))
            {
                throw new Exception("文件路径错误，该路径下不存在文件。");
            }
            FileInfo uploadFile = new FileInfo(multiUploadReq.FilePath);

            // 获取对象存储信息，判断得出分块的大小
            FileOsoptionRes result = apiInstance.FileOsoptionPost();
            Console.WriteLine(result);
            long partMinSize = (long)result.Partminsize;
            if (partMinSize <= this.minSize)
            {
                partMinSize = this.minSize;
            }
            long partMaxSize = (long)result.Partmaxsize;
            long partMaxNum = (long)result.Partmaxnum;
            long partSize = partMinSize;
            int partCount;

            while (true)
            {
                if (partSize > partMaxSize)
                {
                    throw new Exception("上传文件过大!");
                }
                partCount = (int) (uploadFile.Length / partSize);
                if (uploadFile.Length == 0 || uploadFile.Length % partSize != 0)
                {
                    ++partCount;
                }
                if (partCount <= partMaxNum)
                {
                    break;
                }
                partSize += partMinSize;
            }

            // 调用 osinitmultiupload API
            multiUploadReq.Length = uploadFile.Length;
            multiUploadReq.Name = uploadFile.Name;

            FileOsinitmultiuploadReq osinitmultiuploadBody = new FileOsinitmultiuploadReq();
            osinitmultiuploadBody = multiUploadReq;
            FileOsinitmultiuploadRes osinitmultiuploadResult = apiInstance.FileOsinitmultiuploadPost(osinitmultiuploadBody);
            Console.WriteLine(osinitmultiuploadResult);

            String retDocId = osinitmultiuploadResult.Docid;
            String retRev = osinitmultiuploadResult.Rev;
            String retUploadId = osinitmultiuploadResult.Uploadid;

            // 调用 osuploadpart API
            String parts = "1-" + partCount;
            FileOsuploadpartReq osuploadpartBody = new FileOsuploadpartReq();
            osuploadpartBody.Docid = retDocId;
            osuploadpartBody.Rev = retRev;
            osuploadpartBody.Uploadid = retUploadId;
            osuploadpartBody.Parts = parts;

            FileOsuploadpartRes osuploadpartResult = apiInstance.FileOsuploadpartPost(osuploadpartBody);
            Console.WriteLine(osuploadpartResult);

            // 根据服务器返回的对象存储请求，向对象存储分块上传数据
            byte[] buf = new byte[(int)partSize];
 
            FileStream fs = new FileStream(multiUploadReq.FilePath, FileMode.Open);
            int partIndex = 1; // 记录当前处理的是第几个part
            int writeSize = 0; // 记录当前块写入的字节
            Dictionary<string, List<Object>> partInfo = new Dictionary<string, List<Object>>();
            do
            {
                List<String> headers = new List<String>();
                List<String> authRequestList = new List<string>();
                osuploadpartResult.Authrequests.TryGetValue(partIndex.ToString(), out authRequestList);
                for (int i = 2; i < authRequestList.Count; ++i)
                {
                    String header = authRequestList[i];
                    headers.Add(header);
                }
                HttpWebResponse ossResult;
                writeSize = fs.Read(buf, 0, (int)partSize);
                ossResult = ossHttpHelper.SendReqToOSS(authRequestList[0], authRequestList[1], headers, buf.Skip(0).Take(writeSize).ToArray()); // 上传块
     
                Console.WriteLine(ossResult);
                String etag = null;
                // 获取etag,由于报头中"etag"可能为"Etag","ETag","ETAG"等情况，故这里对报头key值进行遍历，将key值变为大写后与"ETAG"进行比较，若相等则让etag等于其value，退出循环。
                WebHeaderCollection headerArray = ossResult.Headers;
                for (int i = 0; i<headerArray.Count; ++i) {
                    String key = headerArray.GetKey(i);
                    if (key.ToUpper().Equals("ETAG")) {
                        etag = headerArray[key];
                        i = headerArray.Count;
                    }
                }
                ossResult.Close();
                List<Object> tempList = new List<Object>();
                tempList.Add(etag);
                tempList.Add(writeSize);
                partInfo.Add(partIndex.ToString(), tempList);
                ++partIndex;
            } while (partIndex <= partCount);
            fs.Close();

            // 调用 oscompleteupload API
            FileOscompleteuploadReq oscompleteuploadBody = new FileOscompleteuploadReq();
            oscompleteuploadBody.Docid = retDocId;
            oscompleteuploadBody.Rev = retRev;
            oscompleteuploadBody.Uploadid = retUploadId;
            oscompleteuploadBody.Partinfo = partInfo;

            String[] completeuploadInfo = new String[2];
            ApiResponse<String> oscompleteuploadResult = apiInstance.FileOscompleteuploadPostWithHttpInfo(oscompleteuploadBody);
            String contentType = "";
            oscompleteuploadResult.Headers.TryGetValue("Content-Type", out contentType);
            String boundary = contentType.Split(';')[1].Split('=')[1];
            completeuploadInfo = Regex.Split(oscompleteuploadResult.Data, "--" + boundary, RegexOptions.IgnoreCase);
            Console.WriteLine(oscompleteuploadResult);

            // 根据服务器返回的索引信息和对象存储请求，向对象存储上传索引信息对块文件进行合并
            byte[] body = Encoding.UTF8.GetBytes(Regex.Replace(completeuploadInfo[1], "\r\n", ""));
            JObject returnJson = (JObject)JsonConvert.DeserializeObject(Regex.Replace(completeuploadInfo[2], "\r\n", ""));
            JArray authRequest = (JArray)returnJson["authrequest"];
            String method = (String)authRequest[0];
            String url = (String)authRequest[1];
            List<String> headers2 = new List<String>();
            for (int i = 2; i<authRequest.Count; i++) {
                headers2.Add((String) authRequest[i]);
            }
            ossHttpHelper.SendReqToOSS(method, url, headers2, body);

            // 调用osendupload API
            FileOsenduploadReq osenduploadBody = new FileOsenduploadReq();
            osenduploadBody.Docid = retDocId;
            osenduploadBody.Rev = retRev;
            FileOsenduploadRes osenduploadResult = apiInstance.FileOsenduploadPost(osenduploadBody);
            Console.WriteLine(osenduploadResult);

        }

    }
}
