﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EASFramework.Main.Framework.Conf
{
    class LoginInfo
    {
        public static String hostIp = "xxx.xxx.xxx.xxx";
        public static int port = 443;
        public static String userName = "userName";
        public static String password = "password";
    }
}
