﻿using EASFramework.Main.Framework.Model;
using EASFramework.Main.Framework.Service;
using EASFramework.Main.Framework.Service.Impl;
using EASFramework.Main.Framework.Util;
using IO.OpenDocAPI.Api;
using IO.OpenDocAPI.Client;
using IO.OpenDocAPI.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;

namespace EASFramework.Main.Framework.Controller
{
    class FileController
    {
        private FileUploadDownloadService fileUploadService;
        private APIInstanceManager apiInstceManager;
        static void Main()
        {
            FileController controller = new FileController();
            //controller.ThumbnailDemo(); //缩略图Demo
            //controller.FileSingleUploadDemo(); //文件上传Demo
            //controller.FileMultiUploadDemo(); //文件分块上传Demo
            //controller.SetfilecustomattributeDemo(); //设置自定义属性Demo
            //controller.GetfilecustomattributeDemo(); //获取自定义属性Demo
            //controller.FileSingleDownloadDemo(); // 文件下载Demo
            controller.GetMessageDemo(); //获取消息通知Demo
        }

        public FileController()
        {
            try 
            {
                apiInstceManager = new APIInstanceManager();
                fileUploadService = new FileUploadDownloadServiceImpl(apiInstceManager);
            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }

        public void FileMultiUploadDemo()
        {
            // 设置传参
            MultiUploadReq body = new MultiUploadReq();
            String filePath = "D:/Xshell_5.0.0.37_setup.exe";
            String parentId = GetDocidByPath("test/测试");
            body.Docid = parentId;
            body.FilePath = filePath;
            body.Ondup = 2;

            // 调用接口
            try 
            {
                fileUploadService.MultiUpload(body);
            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (OSSException e)
            {
                Console.WriteLine(e.ErrCode + " " + e.ErrBody + " " + e.ErrHeaders);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }


        public void FileSingleUploadDemo()
        {
            // 设置传参
            SingleUploadReq body = new SingleUploadReq();
            String filePath = "D:/bigimage.jpg";
            String parentId = GetDocidByPath("test/测试");
            body.Docid = parentId;
            body.FilePath = filePath;
            body.Ondup = 2;

            // 调用接口
            try
            {
                fileUploadService.SingleUpload(body);
            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (OSSException e)
            {
                Console.WriteLine(e.ErrCode + " " + e.ErrBody + " " + e.ErrHeaders);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }

        public void ThumbnailDemo()
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithoutToken;
            // 设置参数
            String docid = GetDocidByPath("test/bigimage.jpg");
            String savePath = "D:/1";
            String saveName = "bigimage.jpg";

            // 调用API，在制定路径下生成缩略图片
            try
            {
                Stream result = apiInstance.FileThumbnailGet(docid, 10000L, 20000L,apiInstceManager.TokenManager.TokenId, null, 75L);
                if (!Directory.Exists(savePath))
                {
                    //如果不存在，创建它
                    Directory.CreateDirectory(savePath);
                }
                String filePath = savePath + "\\" + saveName;
                //写入数据
                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    long readCnt = 0;
                    long readLength = 0;
                    int trunksize = 4 * 1024 * 1024;
                    while (readCnt < result.Length)
                    {
                        byte[] bytes = new byte[trunksize];
                        readLength = result.Read(bytes, 0, trunksize);
                        readCnt = readCnt + readLength;
                        fs.Write(bytes, 0, (int)readLength);
                    }
                }

            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }

        public void GetMessageDemo()
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithToken;
            //设置参数
            MessageGetReq body = new MessageGetReq();

            //调用API,根据返回消息类型来分别处理
            try
            {
                MessageGetRes result = apiInstance.MessageGetPost(body);
                foreach (JObject node in result.Msgs)
                {
                    int type = (int)node["type"];
                    switch (type)
                    {
                        case 1:
                            MessageGetResMsgType1 node1 = node.ToObject<MessageGetResMsgType1>();
                            Console.WriteLine(node1);
                            break;
                        case 2:
                            MessageGetResMsgType2 node2 = node.ToObject<MessageGetResMsgType2>();
                            Console.WriteLine(node2);
                            break;
                        case 3:
                            MessageGetResMsgType3 node3 = node.ToObject<MessageGetResMsgType3>();
                            Console.WriteLine(node3);
                            break;
                        case 5:
                            MessageGetResMsgType5 node5 = node.ToObject<MessageGetResMsgType5>();
                            Console.WriteLine(node5);
                            break;
                        case 7:
                            MessageGetResMsgType7 node7 = node.ToObject<MessageGetResMsgType7>();
                            Console.WriteLine(node7);
                            break;
                        case 9:
                            MessageGetResMsgType9 node9 = node.ToObject<MessageGetResMsgType9>();
                            Console.WriteLine(node9);
                            break;
                        default:
                            Console.WriteLine("未经处理的类型 apptype：" + type);
                            break;
                    }
                }
                Console.ReadKey();

            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }

        public void FileSingleDownloadDemo()
        {
            // 设置传参
            SingleDownloadReq body = new SingleDownloadReq();
            String savePath = "D:/1";
            String docid = GetDocidByPath("test/测试/eclipse (28).zip");
            body.Docid = docid;
            body.SavePath = savePath;
            body.Usehttps = false;
            // 调用接口
            try
            {
                fileUploadService.SingleDownload(body);
            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (OSSException e)
            {
                Console.WriteLine(e.ErrCode + " " + e.ErrBody + " " + e.ErrHeaders);
                Console.ReadKey(); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }

        }

        public void SetfilecustomattributeDemo()
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithToken;
            // 设置参数
            FileSetfilecustomattributeReq body = new FileSetfilecustomattributeReq();
            String docid = GetDocidByPath("test/road-train-landscape-storm-thumb.jpg");
            body.Docid = docid;
            List<FileSetfilecustomattributeReqAttribute> attribute = new List<FileSetfilecustomattributeReqAttribute>();
            FileSetfilecustomattributeReqAttribute element1 = new FileSetfilecustomattributeReqAttribute();
            element1.Id = 1;
            element1.Value = 666;
            attribute.Add(element1);
            FileSetfilecustomattributeReqAttribute element2 = new FileSetfilecustomattributeReqAttribute();
            element2.Id = 3;
            element2.Value = 66;
            attribute.Add(element2);
            FileSetfilecustomattributeReqAttribute element3 = new FileSetfilecustomattributeReqAttribute();
            element3.Id = 7;
            element3.Value = "hello";
            attribute.Add(element3);
            FileSetfilecustomattributeReqAttribute element4 = new FileSetfilecustomattributeReqAttribute();
            element4.Id = 9;
            element4.Value = 3;
            attribute.Add(element4);
            FileSetfilecustomattributeReqAttribute element5 = new FileSetfilecustomattributeReqAttribute();
            element5.Id = 11;
            element5.Value = new int[] { 5, 7 };
            attribute.Add(element5);
            body.Attribute = attribute;
            try
            {
                apiInstance.FileSetfilecustomattributePost(body);
            }
            catch (ApiException e) {
                Console.WriteLine(e.ErrorContent);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }

        public void GetfilecustomattributeDemo()
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithoutToken;
            // 设置参数
            FileGetfilecustomattributeReq body = new FileGetfilecustomattributeReq();
            String docid = GetDocidByPath("test/road-train-landscape-storm-thumb.jpg");
            body.Docid = docid;
            try
            {
                List<FileGetfilecustomattributeResItem> result = apiInstance.FileGetfilecustomattributePost(body);
                foreach (var node in result)
                {
                    Console.WriteLine(node.Name + ":" + node.Value);
                }
                Console.ReadKey();
            }
            catch (ApiException e) {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }
        }

        private String GetDocidByPath(String namePath)
        {
            DefaultApi apiInstance = apiInstceManager.ApiInstanceWithToken;
            FileGetinfobypathReq getinfobypathBody = new FileGetinfobypathReq();
            getinfobypathBody.Namepath = namePath;
            String docId = "";
            try
            {
                docId = apiInstance.FileGetinfobypathPost(getinfobypathBody).Docid;
            }
            catch (ApiException e)
            {
                Console.WriteLine(e.ErrorCode + " " + e.ErrorContent);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data + " " + e.Message);
                Console.ReadKey();
            }

            return docId;
        }

    }
}
