﻿using EASFramework.Main.Framework.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EASFramework.Main.Framework.Service
{
    interface FileUploadDownloadService
    {
        /// <summary>
        /// 文件单次上传
        /// </summary>
        /// <param name="uploadBigDataReq">上传参数</param>
        void SingleUpload(SingleUploadReq uploadReq);

        /// <summary>
        /// 文件分块上传
        /// </summary>
        /// <param name="uploadBigDataReq">上传参数</param>
        void MultiUpload(MultiUploadReq uploadBigDataReq);

        /// <summary>
        /// 单文件下载
        /// </summary>
        /// <param name="uploadBigDataReq">上传参数</param>
        void SingleDownload(SingleDownloadReq downloadReq);
    }
}
