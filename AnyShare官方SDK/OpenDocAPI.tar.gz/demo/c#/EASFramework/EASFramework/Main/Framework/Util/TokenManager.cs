﻿using EASFramework.Main.Framework.Conf;
using IO.OpenDocAPI.Api;
using IO.OpenDocAPI.Client;
using IO.OpenDocAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EASFramework.Main.Framework.Util
{
    class TokenManager
    {
        private String tokenId;

        public string TokenId
        {
            get
            {
                return tokenId;
            }
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        public TokenManager()
        {
            Login();           
        }

        /// <summary>
        /// 登陆
        /// </summary>
        public void Login()
        {
            Configuration.Default.BasePath = "https://" + LoginInfo.hostIp + ":" + LoginInfo.port + "/api/v1";
            Configuration.Default.SetVerifyingSsl(false);
            var apiInstance = new DefaultApi(Configuration.Default);

            Auth1GetnewReq body = new Auth1GetnewReq();
            body.Account = LoginInfo.userName;
            body.Password = CommonUtil.RSAEncode(LoginInfo.password);
            Auth1GetnewReqDeviceinfo deviceinfo = new Auth1GetnewReqDeviceinfo();
            deviceinfo.Ostype = 0;
            body.Deviceinfo = deviceinfo;

            Auth1GetnewRes result = apiInstance.Auth1GetnewPost(body);
            this.tokenId = result.Tokenid;
            
        }
    }
}
