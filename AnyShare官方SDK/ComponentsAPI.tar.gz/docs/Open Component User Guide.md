# 开放Web使用文档

> 从6.0.6开始，开放Web组件不再支持IE8浏览器。
>

## 兼容性

开放组件只支持IE9+及现代浏览器。

开放组件依赖部分ES6的API,因此需要确保在⻚面中引入`es6-shim`、`es6-sham`JS库。

部分组件还需要依赖特定的库文件支持，在组件API中有作说明，需要自行引入。

---

## 使用

### 导入脚本

使用`<link>`标签模块导入 `anyshare.desktop.css` 或 `anyshare.mobile.css`。

使用`<script>`标签或者AMD/CMD模块系统导入 `anyshare.desktop.js` 或 `anyshare.mobile.js`。

```html
<script src="/path/to/es6-shim.js"></script>
<script src="/path/to/es6-sham.js"></script>

<link rel="stylesheet" href="/path/to/anyshare.desktop.css">
<script src="/path/to/anyshare.desktop.js"></script>
```

### 初始化AnyShare对象

使用组件前需要先初始化AnyShare对象并做一些配置：

```html
const Pan = AnyShare({
    locale: 'zh-cn',
    host: 'https://anyshare.eisoo.com',
    EACPPort: 9999,
    EFSPPort: 9124,
    tokenid: function() {
        return sessionStorage.getItem('tokenid')
    }
});
```

### 初始化参数：

#### locale

Web组件显示的界面语言，支持 zh-cn、zh-tw、en-us

类型：boolean

默认值："en-us"

必填：否

#### host

AnyShare服务地址，必需包含`http://`或`https://`

类型：string

默认值：无

必填：是

#### EACPPort

权限控制服务端口

类型：number

默认值：9999（https）/ 9998（http）

必填：否

#### EFSPPort

文档访问控制端口  

类型：number

默认值：9124（https）/ 9123（http）

必填：否

#### tokenid

用户会话token信息，组件内调用开放API时需要传递给服务端。如果传递函数，则每次调用开放API前会执行此函数，并将返回值作为鉴权使用的tokenid  

类型：string | () => string  

默认值：无  

必填：是

## 调用组件

实例化完成后，即可以开始正式使用开放组件。  

组件实例化时接受2个参数，第一个参数为组件配置参数，第二个参数为渲染的容器DOM节点。  

组件实例将返回一个销毁函数，调用该函数进行组件销毁。

```js
var destroy = Pan.Components.Preview({
    doc: {
        docid: 'gns://605E7DA104FF473DBA82A42E8BCD5707/013CE81C765849A5961A78FD43E8C755',
        name: 'AnyShare.pdf',
        size: 101927,
    }
}, document.querySelector('#preview'));

// 销毁预览组件

destroy();
```

---

## 组件API

### Preview 预览组件

依赖：

1. 文档预览依赖 PDFJS https://www.npmjs.com/package/pdfjs-dist
1. 视频预览依赖 hls.js 库 https://github.com/video-dev/hls.js/

#### 参数

##### doc

文档对象，如果是非外链预览则为必需参数。

文档对象可以通过开放API协议获得，为保证逻辑正常，**必须传入包含所有属性的完整文档对象**。

类型：object

默认值：无

必需：否  

##### link

外链对象，如果是外链预览则为必需参数，如果外链开启了密码则必需包含有效密码。

类型：object

默认值：无

必需：否

### DocSelector 文件选择

#### 参数

##### onSelect

选择文档后点击确定触发。  
类型：(doc) => any  
默认值：无  
必需：否

##### onSelectItem

选择全文检索结果后触发。  
类型：(doc) => any  
默认值：无  
必需：否

### Download 下载

#### 参数

##### doc


文档对象，如果是非外链预览则为必需参数。

文档对象可以通过开放API协议获得，为保证逻辑正常，**必须传入包含所有属性的完整文档对象**。

类型：object

默认值：无

必需：否

##### link

外链对象，如果是外链预览则为必需参数，如果外链开启了密码则必需包含有效密码。

类型：object

默认值：无

必需：否

### LinkShare 外链配置

#### 参数

##### doc

文档对象，如果是非外链预览则为必需参数。

文档对象可以通过开放API协议获得，为保证逻辑正常，**必须传入包含所有属性的完整文档对象**。 

类型：object

默认值：无

必需：否

### Share 内链配置

#### 参数

##### doc

文档对象，如果是非外链预览则为必需参数。

文档对象可以通过开放API协议获得，为保证逻辑正常，**必须传入包含所有属性的完整文档对象**。

类型：object

默认值：无

必需：否


### Upload 文件上传

> `demo/upload`目录下有可运行的demo
>

Upload组件本身分为三个子组件，需分别挂载：

1. UploadPicker 文件选择触发

    #### 参数

    ##### dest

    文件上传的目标位置，为一个文档对象。

    文档对象可以通过开放API协议获得，为保证逻辑正常，**必须传入包含所有属性的完整文档对象**。

    类型：object

    默认值：无

    必需：是

    ##### children

    文件选择的触发按钮文本

    类型：string

    默认值：无

    必需：否

1. UploadPanel 文件上传进度

1. UploadExceptions 文件上传异常处理

初始化上传

调用 AnyShare 实例上的 `Core.upload.init` 方法进行初始化上传：

```js
init({
    swf: './libs/webuploader/dist/Uploader.swf',
    fileSizeLimit: 1024 * 1024 * 10 
})
```

上传过程可以通过 AnyShare 实例上的 `Core.upload.subscribe`方法来注册监听事件：

```js
const { subscribe, EventType } = Pan.Core.upload

subscribe(EventType.UPLOAD_SUCCESS, async ({ file }) => {
    console.info(`文件名：${file.name} 上传成功`)
})
```

EventType 包含以下事件类型：

```ts
enum EventType {
    /** 运行环境错误 */
    UPLOAD_RUNTIME_ERROR,

    /** 解析上传目录开始 */
    UPLOAD_PAESR_DIR_START,

    /** 解析上传目录结束 */
    UPLOAD_PAESR_DIR_END,

    /** 文件加入上传队列 */
    UPLOAD_FILE_QUEUED,

    /** 多个文件加入上传队列 */
    UPLOAD_FILES_QUEUED,

    /** 文件移出上传队列 */
    UPLOAD_FILE_DEQUEUED,

    /** 文件取消上传 */
    UPLOAD_FILE_CANCELED,

    /** 开始上传 */
    UPLOAD_START,

    /** 停止上传 */
    UPLOAD_STOP,

    /** 上传发请求之前 */
    UPLOAD_BEFORE_SEND,

    /** 发送上传请求 */
    UPLOAD_ACCEPT,

    /** 上传进度 */
    UPLOAD_PROGRESS,

    /** 上传成功 */
    UPLOAD_SUCCESS,

    /** 上传完成 成功，失败都会触发 */
    UPLOAD_COMPLETE,

    /** 全部上传完成 */
    UPLOAD_FINISHED,

    /** 重置上传 */
    UPLOAD_RESET,

    /** 上传同名冲突 */
    UPLOAD_DUP,

    /** 上传出错 */
    UPLOAD_ERROR,
}
```