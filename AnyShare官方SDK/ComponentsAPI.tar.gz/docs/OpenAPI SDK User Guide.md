# 开放API SDK使用说明

## 兼容性

开放API SDK只支持IE9+及现代浏览器。

开放API SDK依赖部分ES6的API,因此需要确保在⻚面中引入 `es6-shim`、`es6-sham` 库。

---

## 使用

## 导入脚本

```html
<script src="/path/to/es6-shim.js"></script>
<script src="/path/to/es6-sham.js"></script>

<script src="/path/to/anyshare.openapi.js"></script>
```

### 初始化AnyShare对象

使用前需要先初始化AnyShare对象并做一些配置：

###6.0.7版本及之前版本###
```html
window.Pan = AnyShare({
    host: 'https://anyshare.eisoo.com',
    EACPPort: 9999,
    EFSPPort: 9124,
    tokenid: function() {
        return sessionStorage.getItem('tokenid')
    }
});
```

###6.0.8版本及之后版本###
```html
window.Pan = AnyShare({
    host: 'https://anyshare.eisoo.com',
    port:443,
    tokenid: function() {
        return sessionStorage.getItem('tokenid')
    }
});
```

### 初始化参数：

#### host

AnyShare服务地址，必需包含`http://`或`https://`

类型：string

默认值：无

必填：是

#### EACPPort  6.0.7及之前版本需设置

权限控制服务端口

类型：number

默认值：9999（https）/ 9998（http）

必填：否

#### EFSPPort 6.0.7及之前版本需设置

文档访问控制端口

类型：number

默认值：9124（https）/ 9123（http）

必填：否

#### port 6.0.8及之后版本需设置

文档访问控制端口

类型：number

默认值：443

必填：否

#### userid

用户id信息，调用开放API时需要传递给服务端，如果传递函数，则每次调用开放API前会执行此函数，并将返回值作为鉴权使用的userid

类型：string | () => string

默认值：无

必填：是

#### tokenid

用户会话token信息，调用开放API时需要传递给服务端。如果传递函数，则每次调用开放API前会执行此函数，并将返回值作为鉴权使用的tokenid

类型：string | () => string

默认值：无

必填：是

### 调用接口

调用接口返回Promise，返回200时将执行resolve，返回400以上异常码将执行reject

```js

Pan.OpenAPI.eachttp.auth1.getConfig().then(res => {
    // 调用成功
})

Pan.OpenAPI.eachttp.auth1.getNew({account: 'test', password: '...', deviceinfo: { ostype: 6 }}).catch(ex => {
    // 处理异常
})

```

## API

访问控制SDK请使用 `OpenAPI.eachttp` 命名空间，文档访问SDK使用 `OpenAPI.efshttp` 命名空间。

具体的API请参考相关开放API文档。

开放API SDK对开放API文档上的方法做了封装，命名方式使用更符合JS习惯的驼峰命名。建议在使用时利用浏览器的控制台查看命名空间上的正确方法名。
