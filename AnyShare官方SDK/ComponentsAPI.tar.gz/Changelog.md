# Changelog

## 6.0.6

* 不再支持5.0版本的服务器
* 不再支持IE8浏览器
* 初始化AnyShare对象时不再需要传递userid字段

