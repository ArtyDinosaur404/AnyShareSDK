演示demo前需要修改index.html的默认值
1.修改anyshare服务器地址
2.修改用户的userid，tokenid
3.修改所使用组件的需要的参数

修改完成后到index.html目录下开启HTTP服务运行，
如: python －m SimpleHTTPServer 8080

然后再浏览器上使用http://localhost:8080预览组件效果
